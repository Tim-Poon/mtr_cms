from common.component import Component
from common.event import Event
from threading import Thread
import time


class MockSystemMonitor(Component):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.add_event_publisher("system_status")

    def start(self):
        Thread(target=self.__monitor).start()

    def __monitor(self):
        while True:
            self.publish(Event(event_type="system_status", network_good=True))
            time.sleep(60)
