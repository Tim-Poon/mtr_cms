# todo: system include hardware/os, not included on-board-program
# todo: check db status and re-__safe_upload
from common.data_type import *
from common.event import SystemStatusEvent
from common.component import Component
from common.event import Event
import monitor.osutils as osutils
import time
import threading


class SystemMonitor(Component):
    def __init__(self):
        super().__init__()
        self.add_event_publisher(SystemStatusEvent._event_type)

    def start(self):
        threading.Thread(target=self.loop_forever).start()

    def loop_forever(self):
        while 1:
            all_msg = {}
            all_msg["network_status"] = osutils.get_network_status()
            all_msg["CPU_clock_frequency"] = osutils.get_CPU_clock_frequency()
            all_msg["CPU_usage"] = osutils.get_CPU_usage()
            all_msg["CPU_temperature"] = osutils.get_CPU_temperature()
            all_msg["pi_voltage"] = osutils.get_pi_volt()
            all_msg["arm_core_voltage"] = osutils.get_core_volt()
            RAM_info = osutils.get_RAM_info()
            all_msg["RAM_total"] = str(round(int(RAM_info[0]) / 1000, 1))
            all_msg["RAM_used"] = str(round(int(RAM_info[1]) / 1000, 1))
            all_msg["RAM_free"] = round(int(RAM_info[2]) / 1000, 1)
            sd_card_storage_space_info= osutils.get_sd_card_storage_space_info()
            all_msg["sd_card_storage_space_total"] = sd_card_storage_space_info[0]
            all_msg["sd_card_storage_space_used"] = str(sd_card_storage_space_info[1])
            all_msg["sd_card_storage_space_used_percentage"] = sd_card_storage_space_info[3]
            self.publish(SystemStatusEvent(identifier=None,
                                           value=None,
                                           status_dict=all_msg))
            time.sleep(10)
