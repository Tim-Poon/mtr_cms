import time
import sys
from sensors.sensor import Sensor
from threading import Thread, Lock
from config.common import SensorType, SENSOR_SETTING, SENSOR_LIST  # todo: config cross too many layer
from test.mock.mock_sensors.mock_imu import MOCKIMU
import traceback
from functools import partial


import sys, getopt
sys.path.append('.')
# import RTIMU
import sensors.RTIMU as RTIMU
import os.path
import time
import math

class IMU(Sensor):
    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)
        self.send = partial(self.send, sensor_type=SensorType.SENSOR_IMU)  # note: all inputs should use keyword args
        self.log = partial(self.log, sensor_type=SensorType.SENSOR_IMU)
        self.__sensor_handles = self.__init_sensors()  # todo
        self.__thread_dict = {}
        self.__active_flag_list = {sensor_name: False for sensor_name in self.__sensor_handles.keys()}

    def __init_sensors(self):

        if "test.mock.mock_sensors.mock_imu" not in SENSOR_LIST:
            self.log(level='info',
                     msg="Please ensure that the SENSOR_LIST variable in your config file has 'test.mock.mock_sensors.mock_imu'")

        if "sensors.imu" not in SENSOR_LIST:
            self.log(level='info',
                     msg="Please ensure that the SENSOR_LIST variable in your config file has 'sensors.imu'")

        sensors = {}
        try:
            sensors["sensors.imu"] = 'imu'
        except Exception as e:
            self.log(level='warning',
                     msg=f"Unable to init 'sensors.imu': {traceback.format_exc()}")
        else:
            self.log(level='info',
                     msg="init sensor.imu successfully")

        try:
            sensors["test.mock.mock_sensors.mock_imu"] = MOCKIMU()
        except Exception as e:
            self.log(level='warning',
                     msg=f"Unable to init 'test.mock.mock_sensors.mock_imu': {traceback.format_exc()}")
        else:
            self.log(level='info',
                     msg="init test.mock.mock_sensors.mock_imu success")

        return sensors

    def get_sensors_list(self):
        return self.__sensor_handles.keys()

    def activate(self, sensor: str, config: SENSOR_SETTING):
        self.log(level='info', msg=f"activate {sensor}")
        if sensor in self.__sensor_handles and self.__sensor_handles[sensor] is not None:
            sensor_name = sensor
        else:
            self.log(level="warning",
                     msg=f"unable to activate {sensor}")
            return

        if sensor_name not in self.__thread_dict:  # note: need to guarantee all these threads won't crash, because these threads will only start once.
            self.__thread_dict[sensor_name] = Thread(target=self.__read_sensor_data, args=(sensor_name, config))
            self.__thread_dict[sensor_name].start()

        self.__active_flag_list[sensor_name] = True  # note: gurantee that __active_flag is only changed by sensor_manager which is only one thread exist in this process

    def deactivate(self):
        self.__active_flag_list = {sensor_name: False for sensor_name, activate_status in self.__active_flag_list}

    def configure(self, config):
        pass

    def __read_sensor_data(self, sensor_name: str, config: SENSOR_SETTING):
        # imu_handle = self.__sensor_handles[sensor_name]
        # print(imu_handle)
        # sleep_time = 0.01 if config is None else config.time_period_sec
        SETTINGS_FILE = "RTIMULib"
        s = RTIMU.Settings(SETTINGS_FILE)
        imu = RTIMU.RTIMU(s)

        print("IMU Name: " + imu.IMUName())

        if (not imu.IMUInit()):
            print("IMU Init Failed")
            sys.exit(1)
        else:
            print("IMU Init Succeeded")

        # data_collection offline
        # import csv
        # from datetime import datetime
        # headers = ['acc_x', 'acc_y', 'acc_z', 'gyro_x', 'gyro_y', 'gyro_z', 'mag_x', 'mag_y', 'mag_z', 'roll', 'pitch',
        #            'yaw', 'q1', 'q2', 'q3', 'q4', 'ts']
        # f = open('data-imu-'+str(int(time.time()))+'.csv', 'wt')
        # f_csv = csv.writer(f)
        # f_csv.writerow(headers)

        imu.setSlerpPower(0.02)
        imu.setGyroEnable(True)
        imu.setAccelEnable(True)
        imu.setCompassEnable(False)
        poll_interval = imu.IMUGetPollInterval()
        try:
            while True:
                if imu.IMURead():
                    # x, y, z = imu.getFusionData()
                    # print("%f %f %f" % (x,y,z))
                    data = imu.getIMUData()
                    accel = data['accel']
                    gyro = data['gyro']
                    mag = data['compass']
                    f_post = data['fusionPose']
                    accl = imu.getAccelResiduals()
                    # f_qpose = data['fusionQPose']
                    ts = time.time()
                    # --------------------------data_collection offline--------------------------
                    # row = [accel[0], accel[1], accel[2], gyro[0], gyro[1], gyro[2], mag[0], mag[1], mag[2], f_post[0],
                    #                    f_post[1], f_post[2], f_qpose[0], f_qpose[1], f_qpose[2], f_qpose[3], ts]
                    # f_csv.writerow(row)
                    # f.flush()
                    # --------------------------data_collection offline--------------------------
                    # print(accel + gyro + mag + f_post + accl)
                    self.send(values=accel + gyro + mag + f_post + accl)
                    # fusionPose = data["fusionPose"]
                    # print(data["fusionQPose"])
                    # print("r: %f p: %f y: %f" % (math.degrees(fusionPose[0]),
                    #     math.degrees(fusionPose[1]), math.degrees(fusionPose[2])))
                    time.sleep(poll_interval*1.0/1000.0)
            # while True:
            #     if self.__active_flag_list[sensor_name]:
            #         data = imu_handle.getFusionData()
            #         print(data)
            #         # accel = data['accel']
            #         # gyro = data['gyro']
            #         # mag = data['compass']
            #         # self.send(values=accel + gyro + mag)
            #     time.sleep(sleep_time)
        except KeyboardInterrupt:
            pass
