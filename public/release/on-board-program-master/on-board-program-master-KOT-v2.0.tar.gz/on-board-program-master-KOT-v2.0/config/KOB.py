# on-board-program-from-pi version of different sites
from collections import namedtuple
from enum import Enum
from config.common import MTR_SERVICE_MAJOR_MINOR, BEACON_INFO
import os

MAPS = {
        1: [[-58, 7, 0], [-58, 10, 0], [-51, 10, 0], [-51, 7, 0]],
        2: [[-70, 9, 0], [-70, 12, 0], [-29, 12, 0], [-29, 9, 0]],
        3: [[-51, -1, 0], [-51, 10, 0], [-43, 10, 0], [-43, -1, 0]],
        4: [[-43, -1, 0], [-43, 2, 0], [85, 2, 0], [85, -1, 0]],
        5: [[79, 0, 0], [79, 6, 0], [85, 6, 0], [85, 0, 0]],
        6: [[85, 1.5, 0], [85, 11, 0], [110, 11, 0], [110, 1.5, 0]],

        7: [[48, 8, 0], [163, 96, 0], [165, 92, 0], [52, 6, 0]],
        8: [[213, 132, 0], [218, 130, 0], [170, 90, 0], [165, 95, 0]],
        9: [[281, 184, 0], [288.74, 174.5, 0], [255.26, 147.19, 0], [246, 158, 0]],
        10: [[247, 158.5, 0], [250.71, 155.37, 0], [201, 118, 0], [199, 121, 0]],
        11: [[-72.6, 4.04, 0], [-121.18, 42.04, 0], [-124.36, 41.04, 0], [-75.18, 1.04, 0]],
        12: [[-117.18, 42.04, 0], [-124.36, 37.04, 0], [-137.18, 44.04, 0], [-131.18, 49.04, 0]],
}

# [data_pool]
# maximum time range inside a current data pool
window_size_in_sec = 2.
# time gap between two updates in data pool(second)
sec_per_update = 1

# [TRACKING]
CAL_PERIOD_SEC = 1.3  # time gap between two calculations (second)

ALARM_PARAMS = {
    'ALARM_PIN': 17,
    # rule 1: alarm |= within(pos, ALARM_ZONE) and recent(vel_history) > ALARM_VELOCITY_THRESHOLD_HIGHER
    'ALARM_VELOCITY_THRESHOLD_HIGHER': 1.6,
    'ALARM_TOLERANCE_NUMBER': 5,

    # rule 2: alarm |= within(pos, ALARM_ZONE) and step > STEP_ALARM_THRESHOLD_HIGHER
    'STEP_ALARM_THRESHOLD_HIGHER': 12,

    # rule 3: alarm |= within(pos, ALARM_ZONE) and step > STEP_ALARM_THRESHOLD_LOWER and abs(vel) >ALARM_VELOCITY_THRESHOLD_LOWER
    'ALARM_VELOCITY_THRESHOLD_LOWER': 1.5,
    'STEP_ALARM_THRESHOLD_LOWER': 10,

    'ALARM_ZONE': [MAPS[7], MAPS[8], MAPS[9], MAPS[10], MAPS[11], MAPS[12]],  # it can't be empty list or None.
}

FILTER_MODULE_PARAMS = {
    'RSSI_FILTER_ALGO_FILE': "avg_filter.py",
    'RSSI_THRESHOLD': -90,
}

LOCALIZATION_MODULE_PARAMS = {
    'LOCALIZATION_ALGO_FILE': "new_localization_pf.cpython-37m-arm-linux-gnueabihf.so",
    'num_of_particles': 800,
    'max_vel': 2.,  # maximum speed of human, unit in m/s
    'obs_model_mean': [-76.0656, 2.8871],  # mean and variance of P(rssi, distance)
    'obs_model_var': [[53.171, -5.218], [-5.218, 2.912]],
    'loss_model_range': [-120, -110],
    'weight_observe': 0.8,  # mean and variance of P(rssi, distance)
    'weight_loss': 1 - 0.8,
    'map_bound': [[-70, 110], [0, 15]],  # todo: can be calculated from MAPS directly
    'position_candidates_regions': [MAPS[1], MAPS[2], MAPS[3], MAPS[4], MAPS[5], MAPS[6]],
    'grid_size': 0.5,
}

VELOCITY_MODULE_PARAMS = {
    'VELOCITY_ALGO_FILE': "analyse_velocity.py",
    'VELOCITY_LEAST_SQUARE_WINDOW': 15,  # maximum num of position used to calculate velocity via least square
    'LOCALIZATION_CAL_PERIOD': CAL_PERIOD_SEC,
}

SOURCE_INFO_DICT = {}

BEACON_TABLE = {"1001110001": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110001'),pos_x=-96.0943,pos_y=7.0171,pos_z=1,activated=True,addition_info={}),
                "1001110002": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110002'),pos_x=-91.4625,pos_y=6.9919,pos_z=1,activated=True,addition_info={}),
                "1001110003": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110003'),pos_x=-91.1722,pos_y=7.3453,pos_z=1,activated=True,addition_info={}),
                "1001110004": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110004'),pos_x=-91.1722,pos_y=10.5888,pos_z=1,activated=True,addition_info={}),
                "1001110005": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110005'),pos_x=-85.4298,pos_y=10.5888,pos_z=1,activated=True,addition_info={}),
                "1001110006": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110006'),pos_x=-81.8069,pos_y=12.6838,pos_z=1,activated=True,addition_info={}),
                "1001110007": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110007'),pos_x=-76.881,pos_y=12.8101,pos_z=1,activated=True,addition_info={}),
                "1001110008": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110008'),pos_x=-73.0867,pos_y=13.7061,pos_z=1,activated=True,addition_info={}),
                "1001110009": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110009'),pos_x=-63.1093,pos_y=13.4663,pos_z=1,activated=True,addition_info={}),
                "1001110010": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110010'),pos_x=-52.6664,pos_y=13.4663,pos_z=1,activated=True,addition_info={}),
                "1001110011": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110011'),pos_x=-47.4595,pos_y=13.4663,pos_z=1,activated=True,addition_info={}),
                "1001110012": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110012'),pos_x=-42.2472,pos_y=13.4663,pos_z=1,activated=True,addition_info={}),
                "1001110013": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110013'),pos_x=-37.3882,pos_y=13.4663,pos_z=1,activated=True,addition_info={}),
                "1001110014": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110014'),pos_x=-68.3224,pos_y=7.9511,pos_z=1,activated=True,addition_info={}),
                "1001110015": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110015'),pos_x=-59.1282,pos_y=7.9763,pos_z=1,activated=True,addition_info={}),
                "1001110016": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110016'),pos_x=-54.6983,pos_y=7.9763,pos_z=1,activated=True,addition_info={}),
                "1001110017": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110017'),pos_x=-54.3954,pos_y=7.6734,pos_z=1,activated=True,addition_info={}),
                "1001110018": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110018'),pos_x=-54.3954,pos_y=5.1366,pos_z=1,activated=True,addition_info={}),
                "1001110019": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110019'),pos_x=-54.4459,pos_y=1.8616,pos_z=1,activated=True,addition_info={}),
                "1001110020": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110020'),pos_x=-52.6625,pos_y=-0.0505,pos_z=1,activated=True,addition_info={}),
                "1001110021": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110021'),pos_x=-47.4591,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110022": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110022'),pos_x=-42.2354,pos_y=-0.0505,pos_z=1,activated=True,addition_info={}),
                "1001110023": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110023'),pos_x=-39.4272,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110024": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110024'),pos_x=-34.6112,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110025": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110025'),pos_x=-31.798,pos_y=-0.0505,pos_z=1,activated=True,addition_info={}),
                "1001110026": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110026'),pos_x=-28.9981,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110027": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110027'),pos_x=-24.1833,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110028": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110028'),pos_x=-21.372,pos_y=-0.0505,pos_z=1,activated=True,addition_info={}),
                "1001110029": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110029'),pos_x=-15.5235,pos_y=0.366,pos_z=1,activated=True,addition_info={}),
                "1001110030": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110030'),pos_x=-15.1954,pos_y=1.8048,pos_z=1,activated=True,addition_info={}),
                "1001110031": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110031'),pos_x=-6.5174,pos_y=1.8047,pos_z=1,activated=True,addition_info={}),
                "1001110032": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110032'),pos_x=-0.1097,pos_y=0.0,pos_z=1,activated=True,addition_info={}),
                "1001110033": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110033'),pos_x=5.0116,pos_y=-2.032,pos_z=1,activated=True,addition_info={}),
                "1001110034": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110034'),pos_x=10.9245,pos_y=0.0,pos_z=1,activated=True,addition_info={}),
                "1001110035": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110035'),pos_x=13.7408,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110036": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110036'),pos_x=18.5608,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110037": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110037'),pos_x=21.3555,pos_y=-0.0505,pos_z=1,activated=True,addition_info={}),
                "1001110038": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110038'),pos_x=26.5886,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110039": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110039'),pos_x=31.7929,pos_y=-0.0505,pos_z=1,activated=True,addition_info={}),
                "1001110040": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110040'),pos_x=37.0259,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110041": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110041'),pos_x=42.6304,pos_y=-0.0505,pos_z=1,activated=True,addition_info={}),
                "1001110042": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110042'),pos_x=46.0424,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110043": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110043'),pos_x=50.8572,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110044": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110044'),pos_x=53.652,pos_y=-0.0505,pos_z=1,activated=True,addition_info={}),
                "1001110045": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110045'),pos_x=56.4652,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110046": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110046'),pos_x=61.2863,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110047": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110047'),pos_x=64.0893,pos_y=-0.0505,pos_z=1,activated=True,addition_info={}),
                "1001110048": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110048'),pos_x=66.8974,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110049": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110049'),pos_x=71.7186,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110050": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110050'),pos_x=74.5267,pos_y=-0.0505,pos_z=1,activated=True,addition_info={}),
                "1001110051": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110051'),pos_x=77.3348,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110052": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110052'),pos_x=82.1559,pos_y=-1.098,pos_z=1,activated=True,addition_info={}),
                "1001110053": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110053'),pos_x=84.964,pos_y=-0.0505,pos_z=1,activated=True,addition_info={}),
                "1001110054": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110054'),pos_x=90.0616,pos_y=2.7324,pos_z=1,activated=True,addition_info={}),
                "1001110055": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110055'),pos_x=90.5045,pos_y=3.0795,pos_z=1,activated=True,addition_info={}),
                "1001110056": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110056'),pos_x=96.839,pos_y=2.4863,pos_z=1,activated=True,addition_info={}),
                "1001110057": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110057'),pos_x=102.6015,pos_y=2.4863,pos_z=1,activated=True,addition_info={}),
                "1001110058": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110058'),pos_x=108.8488,pos_y=2.4862,pos_z=1,activated=True,addition_info={}),
                "1001110059": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110059'),pos_x=113.8655,pos_y=2.5115,pos_z=1,activated=True,addition_info={}),
                "1001110060": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110060'),pos_x=115.6502,pos_y=11.2451,pos_z=1,activated=True,addition_info={}),
                "1001110061": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110061'),pos_x=108.3491,pos_y=11.2703,pos_z=1,activated=True,addition_info={}),
                "1001110062": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110062'),pos_x=100.8776,pos_y=11.2703,pos_z=1,activated=True,addition_info={}),
                "1001110063": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110063'),pos_x=95.7031,pos_y=11.2451,pos_z=1,activated=True,addition_info={}),
                "1001110064": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001110064'),pos_x=91.2606,pos_y=11.5985,pos_z=1,activated=True,addition_info={}),
                "1001120001": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001120001'),pos_x=-96.3846,pos_y=8.9172,pos_z=1,activated=True,addition_info={}),
                "1001120002": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001120002'),pos_x=-73.3646,pos_y=15.17,pos_z=1,activated=True,addition_info={}),
                "1001120003": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001120003'),pos_x=-62.927,pos_y=15.179,pos_z=1,activated=True,addition_info={}),
                "1001120004": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001120004'),pos_x=-47.3332,pos_y=15.1601,pos_z=1,activated=True,addition_info={}),
                "1001120005": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001120005'),pos_x=-59.4187,pos_y=6.1662,pos_z=1,activated=True,addition_info={}),
                "1001120006": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001120006'),pos_x=95.0215,pos_y=-0.0881,pos_z=1,activated=True,addition_info={}),
                "1001120007": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001120007'),pos_x=96.8894,pos_y=1.2733,pos_z=1,activated=True,addition_info={}),
                "1001120008": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001120008'),pos_x=105.4967,pos_y=-0.0502,pos_z=1,activated=True,addition_info={}),
                "1001120009": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001120009'),pos_x=115.8583,pos_y=13.7442,pos_z=1,activated=True,addition_info={}),
                "1001120010": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001120010'),pos_x=105.4967,pos_y=13.6685,pos_z=1,activated=True,addition_info={}),
                "1001120011": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001120011'),pos_x=100.8652,pos_y=13.6807,pos_z=1,activated=True,addition_info={}),
                "1001120012": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001120012'),pos_x=95.0593,pos_y=13.6685,pos_z=1,activated=True,addition_info={}),
                "1001120013": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1001120013'),pos_x=-10.9232,pos_y=-0.0507,pos_z=1,activated=True,addition_info={})}

if __name__ == "__main__":
    # test for configs
    print(f"\n------ TEST BEACON TABLE in {__file__} ---------\n")
    for beacon_major_minor, beacon_info in BEACON_TABLE.items():
        # print(beacon_info.major_minor)
        assert beacon_major_minor == str(beacon_info.major_minor.raw)

    print("The major minor has correct length")
    print("--------------- ALL TEST PASS -----------------")
