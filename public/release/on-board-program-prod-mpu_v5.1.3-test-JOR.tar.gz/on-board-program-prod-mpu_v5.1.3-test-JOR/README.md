# on-board-program

tool box
- tar zcvf xx.tar.gz xx
compile
```
from distutils.core import setup
from Cython.Build import cythonize

setup(ext_modules=cythonize(["localization_pf.py"]))
```
- python3 ppp.py build_ext