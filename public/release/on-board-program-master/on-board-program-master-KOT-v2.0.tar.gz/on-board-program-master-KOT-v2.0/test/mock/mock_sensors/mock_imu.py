class MOCKIMU:
    def readAccel(self):
        return [0.981, 0, 0]

    def readGyro(self):
        return [0, 0, 0]

    def readMagnet(self):
        return [1, 1, 1]
