# on-board-program

Phase 2 POC project (2020). A program deployed on Raspberry Pi for calculating position and velocity.


### Version Number Update Rules
- Version Number Format：X.X
- Version Number Update(when code change)：we only change number **before dot**
- Version Number Update(when config change): we only change number **after dot**


### Notes
router.py should be the first script to start, something like ros_core in ROS.
Then I should be able to run collector.py, system_monitor.py in arbitrary order, 
Finally, estimator.py is operated.

hci.py is deprecated, its rule is mainly replaced by alarm.py, router.py and collector.py

From coding's perspective, I just need to run start.py, and the service is on.
There's no need to separate collector.py, router.py and system_monitor.py into three processes. as none of them is calculation heavy task, so we only need to run them within one process.
estimator will be run separately in another process.

- Pay attention that estimator is directly receiving data from sensor manager rather than routing back to router before getting the information

- callback pattern, timeout is a problem


- Specify what's the mechanism of Router?
- Specify what's the mechanism of Component?



### event(message) and its format
Principle: The content of event can be defined arbitrarily so long as it's published in `Event` type and or its decendent type(e.g. `SensorEvent`), decoding the event is the job of listener. 

- `log`: `Event`  
    - definition: log data will be received by `Network`. 
        - `event_type`: "log"
        - `timestamp`: `time.time()`
        - `msg`: any string 
        - (optional): all other keyword arguments can be passed in, for example, `level` keyword is not defined yet.
    - example usage
        ```python 
        Event(event_type="log",
              sensor_type=sensor_type,
              timestamp=timestamp,
              msg=msg)```
- `sensor_data`: `SensorEvent`
    - definition: all `sensor_data` is sent from `SensorManager` and will be received by `Network`, `Estimator`, `Debug` component
        - `event_type`: "sensor_data"
        - `sensor_type`: SensorType.IMU or SensorType.BLE or SensorType.WIFI
        - `timestamp`: time.time()
        - `values`: List, the concrete structure will be different from different sensor.
        - (optional): all other keyword arguments can be passed in, for example, `sensor_name` keyword is not defined yet.
    - example usage
      ```python
        SensorEvent(event_type="sensor_data",
                    sensor_type=sensor_type,
                    timestamp=timestamp,
                    values=values,
                    **kwargs)```
     
- `data_backup`: `Event`
    - definition: send from `Network` receive by `BackUpSystem`, this event is not designed to be exposed to other component.
        - `event_type`: "data_backup" 
        - `content`: string
    - example usage
      ```python
      Event("data_backup", content="xyausoai10ASI10jaa")
      ```
      
- `resend_data`: `Event`
    - definition:
        - `event_type`: "resend_data"
        - `data`: string
        - `id`: int
    - example usage
      ```python
      
      ``` 
- `resend_success`: `Event`
    - definition: send from `BackUpSystem` to `Network`, once `BackupSystem` receive this, it will clear out successfully resend entry. This event is not designed to be exposed to other component.
        - `event_type`: "resend_success" 
        - `ids`: List[int]
        - (optional): something like `signature` can be defined to ensure the event publisher is the desired one. 
    - example usage
        ```python
        Event(event_type="resend_success", ids=[1,2,3])
  
        ```
        
- `result_data`: `UploadableEvent`
    - definition: send from `Estimator`, receive by `Network`
        - `event_type`: "result_data"
        - `result`: ((x, y, z), (vx, vy), alarm, ts) 
    - example usage
        ```python
        ?
        ```

- `sensor_pause`: `Event` 
    - definition: it's assumed that this is event got from remote server 
    - example usage:
        ```python
        ?
        ```
