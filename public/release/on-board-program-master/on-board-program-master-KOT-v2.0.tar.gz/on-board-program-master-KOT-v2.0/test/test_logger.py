def test1():
    # todo: two logger send simultaneously to __router to see if __router work correctly.
    pass
