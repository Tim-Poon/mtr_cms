import RPi.GPIO as GPIO
import time
import fan
import speaker
import os
import conf
from threading import Thread
import shop_survey as survey_mode

def button_callback1(channel):
    print(f"Key 1 is pressed")

def button_callback2(channel):
    print(f"Key 2 is pressed")

# todo fan_speed_adjust
# todo button shut down
def button_control(button_on_pin,button_off_pin):
    GPIO.setwarnings(False)  # Ignore warning for now
    GPIO.setmode(GPIO.BOARD)  # Use physical pin numbering
    GPIO.setup(button_on_pin, GPIO.IN,pull_up_down=GPIO.PUD_DOWN)  # Set pinto be an input pin and set initial value to be pulled low (off)
    GPIO.add_event_detect(button_on_pin, GPIO.RISING, callback=button_callback1)  # Setup event on pin rising edge
    GPIO.setup(button_off_pin, GPIO.IN,
               pull_up_down=GPIO.PUD_DOWN)  # Set pinto be an input pin and set initial value to be pulled low (off)
    GPIO.add_event_detect(button_off_pin, GPIO.RISING, callback=button_callback2)  # Setup event on pin rising edge
    while True:
        if GPIO.input(button_on_pin) == GPIO.HIGH:
            time.sleep(0.02)  # time delay
            print("Button needed to be pressed!")
            if GPIO.input(button_on_pin) == GPIO.HIGH:  # decide whether the button is pressed second time
                while GPIO.input(button_on_pin) == GPIO.HIGH:  # after pressing, the button will be loosen,
                    # decide the button
                    Thread(target=survey_mode.execute()).start()

if __name__ == '__main__':
   button_on_pin = conf.button_on_pin
   button_off_pin = conf.button_off_pin
   button_control(button_on_pin,button_off_pin)
