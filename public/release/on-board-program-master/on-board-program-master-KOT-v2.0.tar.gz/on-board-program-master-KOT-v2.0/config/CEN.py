# on-board-program-from-pi version of different sites
from collections import namedtuple
from enum import Enum
from config.common import MTR_SERVICE_MAJOR_MINOR, BEACON_INFO
import os

MAPS = {
        1: [[-58, 7, 0], [-58, 10, 0], [-51, 10, 0], [-51, 7, 0]],
        2: [[-70, 9, 0], [-70, 12, 0], [-29, 12, 0], [-29, 9, 0]],
        3: [[-51, -1, 0], [-51, 10, 0], [-43, 10, 0], [-43, -1, 0]],
        4: [[-43, -1, 0], [-43, 2, 0], [85, 2, 0], [85, -1, 0]],
        5: [[79, 0, 0], [79, 6, 0], [85, 6, 0], [85, 0, 0]],
        6: [[85, 1.5, 0], [85, 11, 0], [110, 11, 0], [110, 1.5, 0]],

        7: [[48, 8, 0], [163, 96, 0], [165, 92, 0], [52, 6, 0]],
        8: [[213, 132, 0], [218, 130, 0], [170, 90, 0], [165, 95, 0]],
        9: [[281, 184, 0], [288.74, 174.5, 0], [255.26, 147.19, 0], [246, 158, 0]],
        10: [[247, 158.5, 0], [250.71, 155.37, 0], [201, 118, 0], [199, 121, 0]],
        11: [[-72.6, 4.04, 0], [-121.18, 42.04, 0], [-124.36, 41.04, 0], [-75.18, 1.04, 0]],
        12: [[-117.18, 42.04, 0], [-124.36, 37.04, 0], [-137.18, 44.04, 0], [-131.18, 49.04, 0]],
}

# [data_pool]
# maximum time range inside a current data pool
window_size_in_sec = 2.
# time gap between two updates in data pool(second)
sec_per_update = 1

# [TRACKING]
CAL_PERIOD_SEC = 1.3  # time gap between two calculations (second)

ALARM_PARAMS = {
    'ALARM_PIN': 17,

    # rule 1: alarm |= within(pos, ALARM_ZONE) and recent(vel_history) > ALARM_VELOCITY_THRESHOLD_HIGHER
    'ALARM_VELOCITY_THRESHOLD_HIGHER': 1.6,
    'ALARM_TOLERANCE_NUMBER': 5,

    # rule 2: alarm |= within(pos, ALARM_ZONE) and step > STEP_ALARM_THRESHOLD_HIGHER
    'STEP_ALARM_THRESHOLD_HIGHER': 12,

    # rule 3: alarm |= within(pos, ALARM_ZONE) and step > STEP_ALARM_THRESHOLD_LOWER and abs(vel) >ALARM_VELOCITY_THRESHOLD_LOWER
    'ALARM_VELOCITY_THRESHOLD_LOWER': 1.5,
    'STEP_ALARM_THRESHOLD_LOWER': 10,

    'ALARM_ZONE': [MAPS[7], MAPS[8], MAPS[9], MAPS[10], MAPS[11], MAPS[12]],  # it can't be empty list or None.
}

FILTER_MODULE_PARAMS = {
    'RSSI_FILTER_ALGO_FILE': "avg_filter.py",
    'RSSI_THRESHOLD': -90,
}

LOCALIZATION_MODULE_PARAMS = {
    'LOCALIZATION_ALGO_FILE': "new_localization_pf.cpython-37m-arm-linux-gnueabihf.so",
    'num_of_particles': 800,
    'max_vel': 2.,  # maximum speed of human, unit in m/s
    'obs_model_mean': [-76.0656, 2.8871],  # mean and variance of P(rssi, distance)
    'obs_model_var': [[53.171, -5.218], [-5.218, 2.912]],
    'loss_model_range': [-120, -110],
    'weight_observe': 0.8,  # mean and variance of P(rssi, distance)
    'weight_loss': 1 - 0.8,
    'map_bound': [[-70, 110], [0, 15]],  # todo: can be calculated from MAPS directly
    'position_candidates_regions': [MAPS[1], MAPS[2], MAPS[3], MAPS[4], MAPS[5], MAPS[6]],
    'grid_size': 0.5,
}

VELOCITY_MODULE_PARAMS = {
    'VELOCITY_ALGO_FILE': "analyse_velocity.py",
    'VELOCITY_LEAST_SQUARE_WINDOW': 15,  # maximum num of position used to calculate velocity via least square
    'LOCALIZATION_CAL_PERIOD': CAL_PERIOD_SEC,
}

BEACON_TABLE = {"1003110001": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110001'),pos_x=-13.82,pos_y=30.62,pos_z=1,activated=True,addition_info={}),
                "1003110002": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110002'),pos_x=-6.94,pos_y=30.06,pos_z=1,activated=True,addition_info={}),
                "1003110003": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110003'),pos_x=0.56,pos_y=31.18,pos_z=1,activated=True,addition_info={}),
                "1003110004": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110004'),pos_x=1.12,pos_y=29.99,pos_z=1,activated=True,addition_info={}),
                "1003110005": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110005'),pos_x=-3.37,pos_y=27.03,pos_z=1,activated=True,addition_info={}),
                "1003110006": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110006'),pos_x=0.56,pos_y=21.63,pos_z=1,activated=True,addition_info={}),
                "1003110007": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110007'),pos_x=1.12,pos_y=20.44,pos_z=1,activated=True,addition_info={}),
                "1003110008": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110008'),pos_x=-3.37,pos_y=18.4,pos_z=1,activated=True,addition_info={}),
                "1003110009": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110009'),pos_x=0.56,pos_y=12.08,pos_z=1,activated=True,addition_info={}),
                "1003110010": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110010'),pos_x=1.12,pos_y=10.89,pos_z=1,activated=True,addition_info={}),
                "1003110011": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110011'),pos_x=-3.65,pos_y=9.97,pos_z=1,activated=True,addition_info={}),
                "1003110012": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110012'),pos_x=-3.65,pos_y=5.33,pos_z=1,activated=True,addition_info={}),
                "1003110013": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110013'),pos_x=0.56,pos_y=2.53,pos_z=1,activated=True,addition_info={}),
                "1003110014": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110014'),pos_x=1.12,pos_y=1.26,pos_z=1,activated=True,addition_info={}),
                "1003110015": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110015'),pos_x=9.55,pos_y=1.26,pos_z=1,activated=True,addition_info={}),
                "1003110016": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110016'),pos_x=10.11,pos_y=2.53,pos_z=1,activated=True,addition_info={}),
                "1003110017": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110017'),pos_x=16.44,pos_y=2.53,pos_z=1,activated=True,addition_info={}),
                "1003110018": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110018'),pos_x=16.29,pos_y=9.13,pos_z=1,activated=True,addition_info={}),
                "1003110019": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110019'),pos_x=10.68,pos_y=11.67,pos_z=1,activated=True,addition_info={}),
                "1003110020": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110020'),pos_x=10.11,pos_y=12.08,pos_z=1,activated=True,addition_info={}),
                "1003110021": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110021'),pos_x=9.55,pos_y=10.89,pos_z=1,activated=True,addition_info={}),
                "1003110022": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110022'),pos_x=9.55,pos_y=20.44,pos_z=1,activated=True,addition_info={}),
                "1003110023": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110023'),pos_x=10.68,pos_y=19.24,pos_z=1,activated=True,addition_info={}),
                "1003110024": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110024'),pos_x=10.11,pos_y=21.63,pos_z=1,activated=True,addition_info={}),
                "1003110025": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110025'),pos_x=16.15,pos_y=23.74,pos_z=1,activated=True,addition_info={}),
                "1003110026": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110026'),pos_x=9.55,pos_y=29.99,pos_z=1,activated=True,addition_info={}),
                "1003110027": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110027'),pos_x=10.96,pos_y=31.18,pos_z=1,activated=True,addition_info={}),
                "1003110028": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110028'),pos_x=16.16,pos_y=31.39,pos_z=1,activated=True,addition_info={}),
                "1003110029": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110029'),pos_x=16.15,pos_y=38.77,pos_z=1,activated=True,addition_info={}),
                "1003110030": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110030'),pos_x=0.19,pos_y=-4.36,pos_z=1,activated=True,addition_info={}),
                "1003110031": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110031'),pos_x=1.03,pos_y=-7.92,pos_z=1,activated=True,addition_info={}),
                "1003110032": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110032'),pos_x=10.11,pos_y=-9.13,pos_z=1,activated=True,addition_info={}),
                "1003110033": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110033'),pos_x=15.66,pos_y=-9.13,pos_z=1,activated=True,addition_info={}),
                "1003110034": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110034'),pos_x=22.05,pos_y=-9.13,pos_z=1,activated=True,addition_info={}),
                "1003110035": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110035'),pos_x=34.64,pos_y=-9.13,pos_z=1,activated=True,addition_info={}),
                "1003110036": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110036'),pos_x=23.25,pos_y=-0.28,pos_z=1,activated=True,addition_info={}),
                "1003110037": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110037'),pos_x=31.14,pos_y=-0.0,pos_z=1,activated=True,addition_info={}),
                "1003110038": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110038'),pos_x=39.25,pos_y=0.11,pos_z=1,activated=True,addition_info={}),
                "1003110039": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110039'),pos_x=45.32,pos_y=0.11,pos_z=1,activated=True,addition_info={}),
                "1003110040": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110040'),pos_x=47.2,pos_y=1.26,pos_z=1,activated=True,addition_info={}),
                "1003110041": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110041'),pos_x=50.53,pos_y=3.85,pos_z=1,activated=True,addition_info={}),
                "1003110042": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110042'),pos_x=53.88,pos_y=6.42,pos_z=1,activated=True,addition_info={}),
                "1003110043": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110043'),pos_x=57.39,pos_y=9.12,pos_z=1,activated=True,addition_info={}),
                "1003110044": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110044'),pos_x=60.89,pos_y=11.81,pos_z=1,activated=True,addition_info={}),
                "1003110045": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110045'),pos_x=64.87,pos_y=14.87,pos_z=1,activated=True,addition_info={}),
                "1003110046": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110046'),pos_x=68.85,pos_y=17.92,pos_z=1,activated=True,addition_info={}),
                "1003110047": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110047'),pos_x=73.36,pos_y=21.38,pos_z=1,activated=True,addition_info={}),
                "1003110048": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110048'),pos_x=77.87,pos_y=24.84,pos_z=1,activated=True,addition_info={}),
                "1003110049": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110049'),pos_x=81.95,pos_y=27.98,pos_z=1,activated=True,addition_info={}),
                "1003110050": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110050'),pos_x=86.03,pos_y=31.11,pos_z=1,activated=True,addition_info={}),
                "1003110051": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110051'),pos_x=90.44,pos_y=34.49,pos_z=1,activated=True,addition_info={}),
                "1003110052": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110052'),pos_x=94.94,pos_y=37.95,pos_z=1,activated=True,addition_info={}),
                "1003110053": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110053'),pos_x=98.97,pos_y=41.04,pos_z=1,activated=True,addition_info={}),
                "1003110054": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110054'),pos_x=103.0,pos_y=44.13,pos_z=1,activated=True,addition_info={}),
                "1003110055": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110055'),pos_x=107.19,pos_y=47.42,pos_z=1,activated=True,addition_info={}),
                "1003110056": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110056'),pos_x=111.46,pos_y=50.74,pos_z=1,activated=True,addition_info={}),
                "1003110057": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110057'),pos_x=115.25,pos_y=53.66,pos_z=1,activated=True,addition_info={}),
                "1003110058": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110058'),pos_x=119.12,pos_y=56.61,pos_z=1,activated=True,addition_info={}),
                "1003110059": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110059'),pos_x=123.8,pos_y=60.2,pos_z=1,activated=True,addition_info={}),
                "1003110060": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110060'),pos_x=128.48,pos_y=63.79,pos_z=1,activated=True,addition_info={}),
                "1003110061": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110061'),pos_x=132.39,pos_y=66.8,pos_z=1,activated=True,addition_info={}),
                "1003110062": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110062'),pos_x=136.31,pos_y=69.8,pos_z=1,activated=True,addition_info={}),
                "1003110063": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110063'),pos_x=140.14,pos_y=72.75,pos_z=1,activated=True,addition_info={}),
                "1003110064": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110064'),pos_x=143.57,pos_y=75.39,pos_z=1,activated=True,addition_info={}),
                "1003110065": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110065'),pos_x=146.79,pos_y=77.86,pos_z=1,activated=True,addition_info={}),
                "1003110066": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110066'),pos_x=150.5,pos_y=80.71,pos_z=1,activated=True,addition_info={}),
                "1003110067": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110067'),pos_x=155.64,pos_y=80.49,pos_z=1,activated=True,addition_info={}),
                "1003110068": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110068'),pos_x=158.17,pos_y=82.45,pos_z=1,activated=True,addition_info={}),
                "1003110069": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110069'),pos_x=161.99,pos_y=82.2,pos_z=1,activated=True,addition_info={}),
                "1003110070": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110070'),pos_x=165.19,pos_y=84.56,pos_z=1,activated=True,addition_info={}),
                "1003110071": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110071'),pos_x=172.6,pos_y=90.32,pos_z=1,activated=True,addition_info={}),
                "1003110072": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110072'),pos_x=175.89,pos_y=92.88,pos_z=1,activated=True,addition_info={}),
                "1003110073": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110073'),pos_x=176.57,pos_y=96.64,pos_z=1,activated=True,addition_info={}),
                "1003110074": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110074'),pos_x=179.1,pos_y=98.47,pos_z=1,activated=True,addition_info={}),
                "1003110075": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110075'),pos_x=184.46,pos_y=102.71,pos_z=1,activated=True,addition_info={}),
                "1003110076": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110076'),pos_x=189.49,pos_y=106.61,pos_z=1,activated=True,addition_info={}),
                "1003110077": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110077'),pos_x=195.6,pos_y=111.18,pos_z=1,activated=True,addition_info={}),
                "1003110078": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110078'),pos_x=200.9,pos_y=115.35,pos_z=1,activated=True,addition_info={}),
                "1003110079": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110079'),pos_x=206.21,pos_y=119.4,pos_z=1,activated=True,addition_info={}),
                "1003110080": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110080'),pos_x=211.26,pos_y=123.19,pos_z=1,activated=True,addition_info={}),
                "1003110081": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110081'),pos_x=213.5,pos_y=129.11,pos_z=1,activated=True,addition_info={}),
                "1003110082": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110082'),pos_x=220.74,pos_y=134.67,pos_z=1,activated=True,addition_info={}),
                "1003110083": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110083'),pos_x=227.81,pos_y=140.12,pos_z=1,activated=True,addition_info={}),
                "1003110084": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110084'),pos_x=234.72,pos_y=137.66,pos_z=1,activated=True,addition_info={}),
                "1003110085": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110085'),pos_x=240.09,pos_y=145.46,pos_z=1,activated=True,addition_info={}),
                "1003110086": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110086'),pos_x=243.27,pos_y=147.88,pos_z=1,activated=True,addition_info={}),
                "1003110087": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110087'),pos_x=246.83,pos_y=150.5,pos_z=1,activated=True,addition_info={}),
                "1003110088": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110088'),pos_x=256.42,pos_y=157.81,pos_z=1,activated=True,addition_info={}),
                "1003110089": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110089'),pos_x=251.67,pos_y=154.22,pos_z=1,activated=True,addition_info={}),
                "1003110090": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003110090'),pos_x=237.3,pos_y=143.3,pos_z=1,activated=True,addition_info={}),
                "1003120001": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003120001'),pos_x=18.96,pos_y=34.55,pos_z=1,activated=True,addition_info={}),
                "1003120002": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003120002'),pos_x=155.07,pos_y=83.87,pos_z=1,activated=True,addition_info={}),
                "1003120003": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003120003'),pos_x=159.2,pos_y=87.02,pos_z=1,activated=True,addition_info={}),
                "1003120004": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003120004'),pos_x=163.78,pos_y=90.53,pos_z=1,activated=True,addition_info={}),
                "1003120005": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003120005'),pos_x=173.2,pos_y=97.83,pos_z=1,activated=True,addition_info={}),
                "1003120006": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003120006'),pos_x=182.47,pos_y=105.0,pos_z=1,activated=True,addition_info={}),
                "1003120007": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003120007'),pos_x=196.45,pos_y=115.65,pos_z=1,activated=True,addition_info={}),
                "1003120008": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003120008'),pos_x=201.43,pos_y=119.42,pos_z=1,activated=True,addition_info={}),
                "1003120009": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003120009'),pos_x=206.69,pos_y=123.59,pos_z=1,activated=True,addition_info={}),
                "1003210001": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210001'),pos_x=-42.84,pos_y=41.14,pos_z=2,activated=True,addition_info={}),
                "1003210002": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210002'),pos_x=-41.26,pos_y=35.64,pos_z=2,activated=True,addition_info={}),
                "1003210003": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210003'),pos_x=-45.99,pos_y=36.23,pos_z=2,activated=True,addition_info={}),
                "1003210004": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210004'),pos_x=-49.02,pos_y=35.83,pos_z=2,activated=True,addition_info={}),
                "1003210005": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210005'),pos_x=-42.18,pos_y=35.57,pos_z=2,activated=True,addition_info={}),
                "1003210006": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210006'),pos_x=-42.18,pos_y=30.87,pos_z=2,activated=True,addition_info={}),
                "1003210007": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210007'),pos_x=-52.05,pos_y=31.59,pos_z=2,activated=True,addition_info={}),
                "1003210008": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210008'),pos_x=-41.89,pos_y=28.76,pos_z=2,activated=True,addition_info={}),
                "1003210009": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210009'),pos_x=-46.25,pos_y=28.45,pos_z=2,activated=True,addition_info={}),
                "1003210010": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210010'),pos_x=-47.02,pos_y=29.33,pos_z=2,activated=True,addition_info={}),
                "1003210011": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210011'),pos_x=-55.54,pos_y=26.98,pos_z=2,activated=True,addition_info={}),
                "1003210012": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210012'),pos_x=-41.89,pos_y=21.04,pos_z=2,activated=True,addition_info={}),
                "1003210013": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210013'),pos_x=-46.25,pos_y=20.38,pos_z=2,activated=True,addition_info={}),
                "1003210014": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210014'),pos_x=-55.46,pos_y=19.41,pos_z=2,activated=True,addition_info={}),
                "1003210015": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210015'),pos_x=-41.23,pos_y=17.19,pos_z=2,activated=True,addition_info={}),
                "1003210016": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210016'),pos_x=-46.25,pos_y=18.62,pos_z=2,activated=True,addition_info={}),
                "1003210017": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210017'),pos_x=-47.02,pos_y=19.55,pos_z=2,activated=True,addition_info={}),
                "1003210018": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210018'),pos_x=-46.25,pos_y=10.18,pos_z=2,activated=True,addition_info={}),
                "1003210019": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210019'),pos_x=-41.26,pos_y=9.48,pos_z=2,activated=True,addition_info={}),
                "1003210020": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210020'),pos_x=-41.45,pos_y=6.12,pos_z=2,activated=True,addition_info={}),
                "1003210021": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210021'),pos_x=-46.25,pos_y=8.42,pos_z=2,activated=True,addition_info={}),
                "1003210022": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210022'),pos_x=-47.02,pos_y=9.3,pos_z=2,activated=True,addition_info={}),
                "1003210023": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210023'),pos_x=-55.46,pos_y=9.3,pos_z=2,activated=True,addition_info={}),
                "1003210024": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210024'),pos_x=-59.2,pos_y=6.32,pos_z=2,activated=True,addition_info={}),
                "1003210025": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210025'),pos_x=-41.37,pos_y=1.56,pos_z=2,activated=True,addition_info={}),
                "1003210026": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210026'),pos_x=-46.25,pos_y=0.28,pos_z=2,activated=True,addition_info={}),
                "1003210027": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210027'),pos_x=-46.97,pos_y=-0.99,pos_z=2,activated=True,addition_info={}),
                "1003210028": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210028'),pos_x=-55.46,pos_y=-0.6,pos_z=2,activated=True,addition_info={}),
                "1003210029": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210029'),pos_x=-56.23,pos_y=-1.48,pos_z=2,activated=True,addition_info={}),
                "1003210030": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210030'),pos_x=-59.12,pos_y=-1.4,pos_z=2,activated=True,addition_info={}),
                "1003210031": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210031'),pos_x=-66.32,pos_y=-1.4,pos_z=2,activated=True,addition_info={}),
                "1003210032": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210032'),pos_x=-44.63,pos_y=-5.34,pos_z=2,activated=True,addition_info={}),
                "1003210033": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210033'),pos_x=-47.61,pos_y=-9.96,pos_z=2,activated=True,addition_info={}),
                "1003210034": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210034'),pos_x=-52.2,pos_y=-11.11,pos_z=2,activated=True,addition_info={}),
                "1003210035": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210035'),pos_x=-62.44,pos_y=-11.11,pos_z=2,activated=True,addition_info={}),
                "1003210036": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210036'),pos_x=-68.77,pos_y=-8.31,pos_z=2,activated=True,addition_info={}),
                "1003210037": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210037'),pos_x=-73.8,pos_y=-8.16,pos_z=2,activated=True,addition_info={}),
                "1003210038": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210038'),pos_x=-73.95,pos_y=-8.89,pos_z=2,activated=True,addition_info={}),
                "1003210039": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210039'),pos_x=-76.88,pos_y=-8.96,pos_z=2,activated=True,addition_info={}),
                "1003210040": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210040'),pos_x=-83.72,pos_y=-8.89,pos_z=2,activated=True,addition_info={}),
                "1003210041": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210041'),pos_x=-87.3,pos_y=-7.98,pos_z=2,activated=True,addition_info={}),
                "1003210042": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210042'),pos_x=-89.66,pos_y=-8.41,pos_z=2,activated=True,addition_info={}),
                "1003210043": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210043'),pos_x=-96.47,pos_y=-7.94,pos_z=2,activated=True,addition_info={}),
                "1003210044": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210044'),pos_x=-103.25,pos_y=-11.91,pos_z=2,activated=True,addition_info={}),
                "1003210045": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210045'),pos_x=-108.3,pos_y=-9.3,pos_z=2,activated=True,addition_info={}),
                "1003210046": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210046'),pos_x=-113.42,pos_y=-5.37,pos_z=2,activated=True,addition_info={}),
                "1003210047": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210047'),pos_x=-119.58,pos_y=-0.6,pos_z=2,activated=True,addition_info={}),
                "1003210048": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210048'),pos_x=-125.67,pos_y=4.02,pos_z=2,activated=True,addition_info={}),
                "1003210049": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210049'),pos_x=-128.64,pos_y=5.95,pos_z=2,activated=True,addition_info={}),
                "1003210050": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210050'),pos_x=-131.88,pos_y=8.43,pos_z=2,activated=True,addition_info={}),
                "1003210051": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210051'),pos_x=-153.77,pos_y=24.05,pos_z=2,activated=True,addition_info={}),
                "1003210052": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210052'),pos_x=-157.29,pos_y=26.25,pos_z=2,activated=True,addition_info={}),
                "1003210053": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210053'),pos_x=-160.34,pos_y=34.03,pos_z=2,activated=True,addition_info={}),
                "1003210054": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210054'),pos_x=-156.04,pos_y=33.92,pos_z=2,activated=True,addition_info={}),
                "1003210055": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210055'),pos_x=-151.72,pos_y=34.69,pos_z=2,activated=True,addition_info={}),
                "1003210056": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210056'),pos_x=-151.49,pos_y=34.69,pos_z=2,activated=True,addition_info={}),
                "1003210057": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210057'),pos_x=-148.11,pos_y=35.03,pos_z=2,activated=True,addition_info={}),
                "1003210058": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210058'),pos_x=-147.53,pos_y=34.58,pos_z=2,activated=True,addition_info={}),
                "1003210059": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210059'),pos_x=-144.31,pos_y=32.34,pos_z=2,activated=True,addition_info={}),
                "1003210060": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210060'),pos_x=-144.23,pos_y=32.12,pos_z=2,activated=True,addition_info={}),
                "1003210061": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210061'),pos_x=-141.54,pos_y=30.44,pos_z=2,activated=True,addition_info={}),
                "1003210062": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210062'),pos_x=-136.79,pos_y=26.92,pos_z=2,activated=True,addition_info={}),
                "1003210063": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210063'),pos_x=-129.82,pos_y=26.16,pos_z=2,activated=True,addition_info={}),
                "1003210064": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210064'),pos_x=-127.87,pos_y=20.78,pos_z=2,activated=True,addition_info={}),
                "1003210065": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210065'),pos_x=-127.69,pos_y=20.78,pos_z=2,activated=True,addition_info={}),
                "1003210066": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210066'),pos_x=-124.72,pos_y=18.4,pos_z=2,activated=True,addition_info={}),
                "1003210067": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210067'),pos_x=-124.53,pos_y=18.36,pos_z=2,activated=True,addition_info={}),
                "1003210068": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210068'),pos_x=-121.56,pos_y=15.98,pos_z=2,activated=True,addition_info={}),
                "1003210069": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210069'),pos_x=-121.34,pos_y=15.98,pos_z=2,activated=True,addition_info={}),
                "1003210070": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210070'),pos_x=-118.33,pos_y=13.56,pos_z=2,activated=True,addition_info={}),
                "1003210071": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210071'),pos_x=-118.19,pos_y=13.48,pos_z=2,activated=True,addition_info={}),
                "1003210072": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210072'),pos_x=-115.18,pos_y=11.06,pos_z=2,activated=True,addition_info={}),
                "1003210073": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210073'),pos_x=-115.03,pos_y=10.99,pos_z=2,activated=True,addition_info={}),
                "1003210074": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210074'),pos_x=-111.95,pos_y=8.47,pos_z=2,activated=True,addition_info={}),
                "1003210075": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210075'),pos_x=-111.77,pos_y=8.5,pos_z=2,activated=True,addition_info={}),
                "1003210076": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210076'),pos_x=-106.65,pos_y=3.6,pos_z=2,activated=True,addition_info={}),
                "1003210077": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210077'),pos_x=-101.43,pos_y=-0.42,pos_z=2,activated=True,addition_info={}),
                "1003210078": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210078'),pos_x=-98.6,pos_y=2.45,pos_z=2,activated=True,addition_info={}),
                "1003210079": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003210079'),pos_x=-91.82,pos_y=-1.36,pos_z=2,activated=True,addition_info={}),
                "1003220001": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003220001'),pos_x=-31.17,pos_y=2.85,pos_z=2,activated=True,addition_info={}),
                "1003220002": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003220002'),pos_x=-41.31,pos_y=-5.62,pos_z=2,activated=True,addition_info={}),
                "1003220003": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003220003'),pos_x=-71.2,pos_y=-10.07,pos_z=2,activated=True,addition_info={}),
                "1003220004": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003220004'),pos_x=-92.21,pos_y=-10.87,pos_z=2,activated=True,addition_info={}),
                "1003220005": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003220005'),pos_x=-116.02,pos_y=-10.08,pos_z=2,activated=True,addition_info={}),
                "1003220006": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003220006'),pos_x=-120.49,pos_y=-6.6,pos_z=2,activated=True,addition_info={}),
                "1003220007": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003220007'),pos_x=-162.29,pos_y=30.75,pos_z=2,activated=True,addition_info={}),
                "1003220008": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003220008'),pos_x=-155.25,pos_y=38.95,pos_z=2,activated=True,addition_info={}),
                "1003220009": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003220009'),pos_x=-143.7,pos_y=37.18,pos_z=2,activated=True,addition_info={}),
                "1003220010": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003220010'),pos_x=-123.56,pos_y=21.11,pos_z=2,activated=True,addition_info={}),
                "1003220011": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1003220011'),pos_x=-114.86,pos_y=14.47,pos_z=2,activated=True,addition_info={})}

if __name__ == "__main__":
    # test for configs
    print(f"\n------ TEST BEACON TABLE in {__file__} ---------\n")
    for beacon_major_minor, beacon_info in BEACON_TABLE.items():
        # print(beacon_info.major_minor)
        assert beacon_major_minor == str(beacon_info.major_minor.raw)

    print("The major minor has correct length")
    print("--------------- ALL TEST PASS -----------------")
