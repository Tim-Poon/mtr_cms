# on-board-program-from-pi version of different sites
from collections import namedtuple
from enum import Enum
from config.common import MTR_SERVICE_MAJOR_MINOR, BEACON_INFO
import os

MAPS = {
        1: [[-58, 7, 0], [-58, 10, 0], [-51, 10, 0], [-51, 7, 0]],
        2: [[-70, 9, 0], [-70, 12, 0], [-29, 12, 0], [-29, 9, 0]],
        3: [[-51, -1, 0], [-51, 10, 0], [-43, 10, 0], [-43, -1, 0]],
        4: [[-43, -1, 0], [-43, 2, 0], [85, 2, 0], [85, -1, 0]],
        5: [[79, 0, 0], [79, 6, 0], [85, 6, 0], [85, 0, 0]],
        6: [[85, 1.5, 0], [85, 11, 0], [110, 11, 0], [110, 1.5, 0]],

        7: [[48, 8, 0], [163, 96, 0], [165, 92, 0], [52, 6, 0]],
        8: [[213, 132, 0], [218, 130, 0], [170, 90, 0], [165, 95, 0]],
        9: [[281, 184, 0], [288.74, 174.5, 0], [255.26, 147.19, 0], [246, 158, 0]],
        10: [[247, 158.5, 0], [250.71, 155.37, 0], [201, 118, 0], [199, 121, 0]],
        11: [[-72.6, 4.04, 0], [-121.18, 42.04, 0], [-124.36, 41.04, 0], [-75.18, 1.04, 0]],
        12: [[-117.18, 42.04, 0], [-124.36, 37.04, 0], [-137.18, 44.04, 0], [-131.18, 49.04, 0]],
}

# [data_pool]
# maximum time range inside a current data pool
window_size_in_sec = 2.
# time gap between two updates in data pool(second)
sec_per_update = 1

# [TRACKING]
CAL_PERIOD_SEC = 1.3  # time gap between two calculations (second)

ALARM_PARAMS = {
    'ALARM_PIN': 17,

    # rule 1: alarm |= within(pos, ALARM_ZONE) and recent(vel_history) > ALARM_VELOCITY_THRESHOLD_HIGHER
    'ALARM_VELOCITY_THRESHOLD_HIGHER': 1.6,
    'ALARM_TOLERANCE_NUMBER': 5,

    # rule 2: alarm |= within(pos, ALARM_ZONE) and step > STEP_ALARM_THRESHOLD_HIGHER
    'STEP_ALARM_THRESHOLD_HIGHER': 12,

    # rule 3: alarm |= within(pos, ALARM_ZONE) and step > STEP_ALARM_THRESHOLD_LOWER and abs(vel)
    # >ALARM_VELOCITY_THRESHOLD_LOWER
    'ALARM_VELOCITY_THRESHOLD_LOWER': 1.5,
    'STEP_ALARM_THRESHOLD_LOWER': 10,

    'ALARM_ZONE': [MAPS[7], MAPS[8], MAPS[9], MAPS[10], MAPS[11], MAPS[12]],  # it can't be empty list or None.
}

FILTER_MODULE_PARAMS = {
    'RSSI_FILTER_ALGO_FILE': "avg_filter.py",
    'RSSI_THRESHOLD': -90,
}

LOCALIZATION_MODULE_PARAMS = {
    'LOCALIZATION_ALGO_FILE': "new_localization_pf.cpython-37m-arm-linux-gnueabihf.so",
    'num_of_particles': 800,
    'max_vel': 2.,  # maximum speed of human, unit in m/s
    'obs_model_mean': [-76.0656, 2.8871],  # mean and variance of P(rssi, distance)
    'obs_model_var': [[53.171, -5.218], [-5.218, 2.912]],
    'loss_model_range': [-120, -110],
    'weight_observe': 0.8,  # mean and variance of P(rssi, distance)
    'weight_loss': 1 - 0.8,
    'map_bound': [[-70, 110], [0, 15]],  # todo: can be calculated from MAPS directly
    'position_candidates_regions': [MAPS[1], MAPS[2], MAPS[3], MAPS[4], MAPS[5], MAPS[6]],
    'grid_size': 0.5,
}

VELOCITY_MODULE_PARAMS = {
    'VELOCITY_ALGO_FILE': "analyse_velocity.py",
    'VELOCITY_LEAST_SQUARE_WINDOW': 15,  # maximum num of position used to calculate velocity via least square
    'LOCALIZATION_CAL_PERIOD': CAL_PERIOD_SEC,
}

BEACON_TABLE = {"1002110001": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110001'),pos_x=0.2422,pos_y=3.2605,pos_z=1,activated=True,addition_info={}),
                "1002110002": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110002'),pos_x=2.6862,pos_y=6.6179,pos_z=1,activated=True,addition_info={}),
                "1002110003": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110003'),pos_x=8.0088,pos_y=3.2605,pos_z=1,activated=True,addition_info={}),
                "1002110004": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110004'),pos_x=11.8293,pos_y=6.6179,pos_z=1,activated=True,addition_info={}),
                "1002110005": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110005'),pos_x=15.8201,pos_y=3.2605,pos_z=1,activated=True,addition_info={}),
                "1002110006": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110006'),pos_x=19.5645,pos_y=6.6179,pos_z=1,activated=True,addition_info={}),
                "1002110007": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110007'),pos_x=23.3523,pos_y=3.2605,pos_z=1,activated=True,addition_info={}),
                "1002110008": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110008'),pos_x=24.4539,pos_y=6.712,pos_z=1,activated=True,addition_info={}),
                "1002110009": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110009'),pos_x=31.0719,pos_y=3.2605,pos_z=1,activated=True,addition_info={}),
                "1002110010": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110010'),pos_x=30.975,pos_y=6.8089,pos_z=1,activated=True,addition_info={}),
                "1002110011": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110011'),pos_x=31.2629,pos_y=3.2605,pos_z=1,activated=True,addition_info={}),
                "1002110012": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110012'),pos_x=38.4565,pos_y=-0.191,pos_z=1,activated=True,addition_info={}),
                "1002110013": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110013'),pos_x=43.1563,pos_y=2.9727,pos_z=1,activated=True,addition_info={}),
                "1002110014": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110014'),pos_x=43.3473,pos_y=3.0211,pos_z=1,activated=True,addition_info={}),
                "1002110015": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110015'),pos_x=49.6774,pos_y=2.9727,pos_z=1,activated=True,addition_info={}),
                "1002110016": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110016'),pos_x=56.0047,pos_y=3.0695,pos_z=1,activated=True,addition_info={}),
                "1002110017": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110017'),pos_x=62.332,pos_y=3.0211,pos_z=1,activated=True,addition_info={}),
                "1002110018": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110018'),pos_x=68.6136,pos_y=3.2135,pos_z=1,activated=True,addition_info={}),
                "1002110019": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110019'),pos_x=74.9921,pos_y=3.0211,pos_z=1,activated=True,addition_info={}),
                "1002110020": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110020'),pos_x=81.1284,pos_y=3.0695,pos_z=1,activated=True,addition_info={}),
                "1002110021": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110021'),pos_x=90.3343,pos_y=4.6998,pos_z=1,activated=True,addition_info={}),
                "1002110022": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110022'),pos_x=90.4284,pos_y=9.5906,pos_z=1,activated=True,addition_info={}),
                "1002110023": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110023'),pos_x=90.4284,pos_y=9.7816,pos_z=1,activated=True,addition_info={}),
                "1002110024": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110024'),pos_x=90.4284,pos_y=14.6724,pos_z=1,activated=True,addition_info={}),
                "1002110025": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110025'),pos_x=85.8255,pos_y=16.5905,pos_z=1,activated=True,addition_info={}),
                "1002110026": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110026'),pos_x=81.507,pos_y=19.6942,pos_z=1,activated=True,addition_info={}),
                "1002110027": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110027'),pos_x=75.4754,pos_y=19.6256,pos_z=1,activated=True,addition_info={}),
                "1002110028": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110028'),pos_x=69.5948,pos_y=19.5428,pos_z=1,activated=True,addition_info={}),
                "1002110029": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110029'),pos_x=61.2831,pos_y=19.4582,pos_z=1,activated=True,addition_info={}),
                "1002110030": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110030'),pos_x=57.5381,pos_y=19.4663,pos_z=1,activated=True,addition_info={}),
                "1002110031": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110031'),pos_x=52.9858,pos_y=19.4494,pos_z=1,activated=True,addition_info={}),
                "1002110032": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110032'),pos_x=48.3322,pos_y=19.4663,pos_z=1,activated=True,addition_info={}),
                "1002110033": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110033'),pos_x=45.4038,pos_y=15.7408,pos_z=1,activated=True,addition_info={}),
                "1002110034": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110034'),pos_x=45.3069,pos_y=15.7408,pos_z=1,activated=True,addition_info={}),
                "1002110035": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110035'),pos_x=36.9646,pos_y=15.6439,pos_z=1,activated=True,addition_info={}),
                "1002110036": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110036'),pos_x=36.8705,pos_y=15.6439,pos_z=1,activated=True,addition_info={}),
                "1002110037": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110037'),pos_x=31.1688,pos_y=32.7886,pos_z=1,activated=True,addition_info={}),
                "1002110038": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110038'),pos_x=31.1661,pos_y=28.2497,pos_z=1,activated=True,addition_info={}),
                "1002110039": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110039'),pos_x=31.1688,pos_y=19.3694,pos_z=1,activated=True,addition_info={}),
                "1002110040": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110040'),pos_x=29.9205,pos_y=16.0148,pos_z=1,activated=True,addition_info={}),
                "1002110041": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110041'),pos_x=28.0992,pos_y=15.7269,pos_z=1,activated=True,addition_info={}),
                "1002110042": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110042'),pos_x=22.057,pos_y=15.7269,pos_z=1,activated=True,addition_info={}),
                "1002110043": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110043'),pos_x=18.6078,pos_y=19.3579,pos_z=1,activated=True,addition_info={}),
                "1002110044": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110044'),pos_x=18.6063,pos_y=9.5946,pos_z=1,activated=True,addition_info={}),
                "1002110045": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110045'),pos_x=24.4539,pos_y=11.7938,pos_z=1,activated=True,addition_info={}),
                "1002110046": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110046'),pos_x=30.975,pos_y=11.7938,pos_z=1,activated=True,addition_info={}),
                "1002110047": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110047'),pos_x=35.7692,pos_y=12.167,pos_z=1,activated=True,addition_info={}),
                "1002110048": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110048'),pos_x=36.4463,pos_y=12.7669,pos_z=1,activated=True,addition_info={}),
                "1002110049": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110049'),pos_x=37.1235,pos_y=12.1747,pos_z=1,activated=True,addition_info={}),
                "1002110050": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110050'),pos_x=36.431,pos_y=11.5979,pos_z=1,activated=True,addition_info={}),
                "1002110051": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110051'),pos_x=44.2055,pos_y=12.1547,pos_z=1,activated=True,addition_info={}),
                "1002110052": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110052'),pos_x=44.8712,pos_y=12.7736,pos_z=1,activated=True,addition_info={}),
                "1002110053": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110053'),pos_x=45.5602,pos_y=12.1701,pos_z=1,activated=True,addition_info={}),
                "1002110054": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110054'),pos_x=45.4766,pos_y=11.5899,pos_z=1,activated=True,addition_info={}),
                "1002110055": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110055'),pos_x=52.6447,pos_y=12.1694,pos_z=1,activated=True,addition_info={}),
                "1002110056": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110056'),pos_x=53.3226,pos_y=12.7688,pos_z=1,activated=True,addition_info={}),
                "1002110057": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110057'),pos_x=53.9904,pos_y=12.1854,pos_z=1,activated=True,addition_info={}),
                "1002110058": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110058'),pos_x=53.3274,pos_y=11.5899,pos_z=1,activated=True,addition_info={}),
                "1002110059": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110059'),pos_x=61.093,pos_y=12.1637,pos_z=1,activated=True,addition_info={}),
                "1002110060": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110060'),pos_x=61.7458,pos_y=12.7604,pos_z=1,activated=True,addition_info={}),
                "1002110061": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110061'),pos_x=66.0053,pos_y=11.8961,pos_z=1,activated=True,addition_info={}),
                "1002110062": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110062'),pos_x=69.5256,pos_y=12.7542,pos_z=1,activated=True,addition_info={}),
                "1002110063": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110063'),pos_x=79.3072,pos_y=12.7542,pos_z=1,activated=True,addition_info={}),
                "1002110064": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110064'),pos_x=87.0724,pos_y=12.7542,pos_z=1,activated=True,addition_info={}),
                "1002110065": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110065'),pos_x=86.4012,pos_y=12.1785,pos_z=1,activated=True,addition_info={}),
                "1002110066": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110066'),pos_x=87.0724,pos_y=7.6725,pos_z=1,activated=True,addition_info={}),
                "1002110067": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110067'),pos_x=86.4012,pos_y=7.1438,pos_z=1,activated=True,addition_info={}),
                "1002110068": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110068'),pos_x=79.3091,pos_y=7.1249,pos_z=1,activated=True,addition_info={}),
                "1002110069": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110069'),pos_x=78.6377,pos_y=6.6176,pos_z=1,activated=True,addition_info={}),
                "1002110070": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110070'),pos_x=70.868,pos_y=6.6179,pos_z=1,activated=True,addition_info={}),
                "1002110071": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110071'),pos_x=65.9979,pos_y=7.4747,pos_z=1,activated=True,addition_info={}),
                "1002110072": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110072'),pos_x=61.7642,pos_y=6.6161,pos_z=1,activated=True,addition_info={}),
                "1002110073": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110073'),pos_x=61.089,pos_y=7.1076,pos_z=1,activated=True,addition_info={}),
                "1002110074": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110074'),pos_x=53.9942,pos_y=7.1464,pos_z=1,activated=True,addition_info={}),
                "1002110075": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110075'),pos_x=53.3271,pos_y=6.6109,pos_z=1,activated=True,addition_info={}),
                "1002110076": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110076'),pos_x=52.6495,pos_y=7.1411,pos_z=1,activated=True,addition_info={}),
                "1002110077": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110077'),pos_x=53.3137,pos_y=7.6948,pos_z=1,activated=True,addition_info={}),
                "1002110079": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110079'),pos_x=44.879,pos_y=6.6179,pos_z=1,activated=True,addition_info={}),
                "1002110080": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110080'),pos_x=44.1997,pos_y=7.1381,pos_z=1,activated=True,addition_info={}),
                "1002110081": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110081'),pos_x=44.879,pos_y=7.6725,pos_z=1,activated=True,addition_info={}),
                "1002110082": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110082'),pos_x=37.1136,pos_y=7.1474,pos_z=1,activated=True,addition_info={}),
                "1002110083": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110083'),pos_x=36.4427,pos_y=6.6151,pos_z=1,activated=True,addition_info={}),
                "1002110084": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110084'),pos_x=35.7755,pos_y=7.149,pos_z=1,activated=True,addition_info={}),
                "1002110085": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110085'),pos_x=36.4363,pos_y=7.6709,pos_z=1,activated=True,addition_info={}),
                "1002110086": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002110086'),pos_x=31.1661,pos_y=23.2189,pos_z=1,activated=True,addition_info={}),
                "1002120001": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002120001'),pos_x=7.0968,pos_y=0.191,pos_z=1,activated=True,addition_info={}),
                "1002120002": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002120002'),pos_x=22.961,pos_y=0.203,pos_z=1,activated=True,addition_info={}),
                "1002120003": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002120003'),pos_x=71.5409,pos_y=0.1106,pos_z=1,activated=True,addition_info={}),
                "1002120004": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002120004'),pos_x=94.6432,pos_y=12.2343,pos_z=1,activated=True,addition_info={}),
                "1002120005": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002120005'),pos_x=41.8554,pos_y=18.7134,pos_z=1,activated=True,addition_info={}),
                "1002120006": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002120006'),pos_x=26.278,pos_y=18.6996,pos_z=1,activated=True,addition_info={}),
                "1002120007": BEACON_INFO(major_minor=MTR_SERVICE_MAJOR_MINOR('1002120007'),pos_x=78.1627,pos_y=0.1106,pos_z=1,activated=True,addition_info={})}


if __name__ == "__main__":
    # test for configs
    print(f"\n------ TEST BEACON TABLE in {__file__} ---------\n")
    for beacon_major_minor, beacon_info in BEACON_TABLE.items():
        # print(beacon_info.major_minor)
        assert beacon_major_minor == str(beacon_info.major_minor.raw)

    print("The major minor has correct length")
    print("--------------- ALL TEST PASS -----------------")
