from multiprocessing import Queue
from typing import List, Union, Tuple, Dict
from threading import Thread
import time
import random


# cython code wrapper class
class LocalizationModule:
    def __init__(self,
                 sensor_batch_input_q: Queue,
                 localization_output_q: Queue,
                 algo_params: Union[Dict, None] = None,
                 map_constraints: Union[List[Tuple[Tuple]], None] = None):
        self.sensor_batch_input_q = sensor_batch_input_q
        self.localization_output_q = localization_output_q
        self.init_pos_flag = False

    def start(self):
        t = Thread(target=self.__calculate_service)
        t.start()
        t.join()
        print("[localization] module start")

    def __calculate_service(self):
        while True:
            print(f"[localization]: try to get data at {time.time()}")
            sensor_data_batch = self.sensor_batch_input_q.get()
            print(f"[localization]: success get data at {time.time()}")
            imu_batch = []
            beacon_batch = []
            wifi_batch = []
            for sensor_data in sensor_data_batch:
                if str(sensor_data[0]) == '1':
                    imu_batch.append(sensor_data)
                elif str(sensor_data[0]) == '2':
                    wifi_batch.append(sensor_data)
                elif str(sensor_data[0]) == '3':
                    beacon_batch.append(sensor_data)

            if not self.init_pos_flag and len(beacon_batch) == 0:
                print("at start time, there's no beacon data, so the localization system won't be able to init pos")
                continue

            # fake algo logic written in python code for testing
            sum_pos_x, sum_pos_y, sum_pos_z = 0, 0, 0
            sum_t = 0
            for sensor_type, beacon_id, rssi, beacon_pos, ts in beacon_batch:
                x, y, z = beacon_pos
                sum_pos_x, sum_pos_y, sum_pos_z = sum_pos_x + x, sum_pos_y + y, sum_pos_z + z
                sum_t += ts
            print(f"[localization]: calculate done try to insert at {time.time()}")
            position = list(map(lambda e: e/len(beacon_batch), [sum_pos_x, sum_pos_y, sum_pos_z]))
            self.localization_output_q.put(position)
            print(f"[localization]: insert done at {time.time()}")
            self.init_pos_flag = True
            time.sleep(random.randint(50, 100) / 100)  # simulate actual calculation time
