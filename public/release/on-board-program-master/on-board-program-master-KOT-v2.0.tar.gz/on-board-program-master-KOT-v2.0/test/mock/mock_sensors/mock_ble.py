from config.common import SensorType
import time


class MOCKBLE:
    def __init__(self, publish_func):
        self.publish_func = publish_func

    def scan(self, freq):
        if freq <= 0:
            freq = 0.5
        while 1:
            self.publish_func(sensor_type=SensorType.SENSOR_BLE, timestamp=time.time(), values=[["manufacturer data", "100101011"], -88])  # todo
            time.sleep(freq)

    def restart(self):
        pass
