import time
import sys
from sensors.sensor import Sensor
from threading import Thread, Lock
from config.common import SensorType, SENSOR_SETTING, SENSOR_LIST  # todo: config cross too many layer
import traceback
from functools import partial
from config.common import PI_BLE_MAC_ADDR

from multiprocessing import Process, Queue
import os,time,random
import numpy as np


import sys, getopt
sys.path.append('.')
# import RTIMU
import sensors.RTIMU as RTIMU
import os.path
import time
import math
import socket
import threading
import json
import zlib

class IMU(Sensor):
    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)
        self.send = partial(self.send, sensor_type=SensorType.SENSOR_IMU)  # note: all inputs should use keyword args
        self.log = partial(self.log, sensor_type=SensorType.SENSOR_IMU)
        self.__sensor_handles = self.__init_sensors()  # todo
        self.__thread_dict = {}
        self.__active_flag_list = {sensor_name: False for sensor_name in self.__sensor_handles.keys()}

    def __init_sensors(self):

        if "test.mock.mock_sensors.mock_imu" not in SENSOR_LIST:
            self.log(level='info',
                     msg="Please ensure that the SENSOR_LIST variable in your config file has 'test.mock.mock_sensors.mock_imu'")

        if "sensors.imu" not in SENSOR_LIST:
            self.log(level='info',
                     msg="Please ensure that the SENSOR_LIST variable in your config file has 'sensors.imu'")

        sensors = {}
        try:
            sensors["sensors.imu"] = 'imu'
        except Exception as e:
            self.log(level='warning',
                     msg=f"Unable to init 'sensors.imu': {traceback.format_exc()}")
        else:
            self.log(level='info',
                     msg="init sensor.imu successfully")

        try:
            sensors["test.mock.mock_sensors.mock_imu"] = MOCKIMU()
        except Exception as e:
            self.log(level='warning',
                     msg=f"Unable to init 'test.mock.mock_sensors.mock_imu': {traceback.format_exc()}")
        else:
            self.log(level='info',
                     msg="init test.mock.mock_sensors.mock_imu success")

        return sensors

    def get_sensors_list(self):
        return self.__sensor_handles.keys()

    def activate(self, sensor: str, config: SENSOR_SETTING):
        self.log(level='info', msg=f"activate {sensor}")
        if sensor in self.__sensor_handles and self.__sensor_handles[sensor] is not None:
            sensor_name = sensor
        else:
            self.log(level="warning",
                     msg=f"unable to activate {sensor}")
            return

        if sensor_name not in self.__thread_dict:  # note: need to guarantee all these threads won't crash, because these threads will only start once.
            self.__thread_dict[sensor_name] = Thread(target=self.__read_sensor_data, args=(sensor_name, config))
            self.__thread_dict[sensor_name].start()

        self.__active_flag_list[sensor_name] = True  # note: gurantee that __active_flag is only changed by sensor_manager which is only one thread exist in this process

    def deactivate(self):
        self.__active_flag_list = {sensor_name: False for sensor_name, activate_status in self.__active_flag_list}

    def configure(self, config):
        pass

    @staticmethod
    def iimu(q, feq):
        SETTINGS_FILE = "RTIMULib"
        s = RTIMU.Settings(SETTINGS_FILE)
        imu = RTIMU.RTIMU(s)

        # T_SRV = 'mtr-uat-internal.smartsensing.biz'
        T_SRV = '143.89.49.63'
        T_PORT = 4001

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            sock.connect((T_SRV, T_PORT))
        except Exception as e:
            print(f"Connect to IMU server DOWN due to: {e}")

        print("IMU Name: " + imu.IMUName())

        start_flag = 0
        while not imu.IMUInit():
            print("IMU Init Failed, trying to re-init")
            time.sleep(3)
            s = RTIMU.Settings(SETTINGS_FILE)
            imu = RTIMU.RTIMU(s)
            start_flag += 1
            if start_flag > 10:
                print("IMU Init DOWN!!!")
                break

        if (not imu.IMUInit()):
            print("IMU Init Failed")
            sys.exit(1)
        else:
            print("IMU Init Succeeded")

        idx = 0
        rate = 500*2
        coll_sec = 0
        ll = []

        decrease = 8 # / 500Hz
        decrease_start = 0
        decrease_ll = []
        decrease_rate = 500*5
        decrease_idx = 0

        imu.setSlerpPower(0.02)
        imu.setGyroEnable(True)
        imu.setAccelEnable(True)
        imu.setCompassEnable(False)
        poll_interval = imu.IMUGetPollInterval()
        try:
            while True:
                if imu.IMURead():
                    data = imu.getIMUData()
                    accel = data['accel']
                    gyro = data['gyro']
                    mag = data['compass']
                    f_post = data['fusionPose']
                    # accl = imu.getAccelResiduals()
                    # self.send(values=accel + gyro + mag + f_post + accl)
                    recv_ts = round(time.time(),3)
                    ll.append([PI_BLE_MAC_ADDR,
                               round(accel[0], 3),
                               round(accel[1], 3),
                               round(accel[2], 3),
                               round(gyro[0], 3),
                               round(gyro[1], 3),
                               round(gyro[2], 3),
                               round(mag[0], 3),
                               round(mag[1], 3),
                               round(mag[2], 3),
                               round(f_post[0], 3),
                               round(f_post[1], 3),
                               round(f_post[2], 3),
                               recv_ts
                              ])
                    decrease_start += 1
                    if decrease_start == decrease:
                        g = np.sqrt(np.square(np.array([accel[0],accel[1],accel[2]])).sum())
                        decrease_ll.append(round(g,3))
                        decrease_start = 0

                    decrease_idx += 1
                    if decrease_idx > decrease_rate:
                        q.put(decrease_ll)
                        decrease_ll = []
                        decrease_idx = 0

                    idx += 1
                    if idx > rate:
                        coll_sec += 1
                        # print('coll pkg =', rate, 'count=', coll_sec, 'seconds')
                        # 
                        pkg = json.dumps(ll).encode('utf-8')
                        compressed_data = zlib.compress(pkg)
                        compressed_data += b'/'
                        # print('org pkg =', len(pkg), 'compressed =', len(compressed_data))
                        try:
                            sock.sendall(compressed_data)
                        except Exception as e:
                            print(f"Send IMU data to server FAIL due to: {e}")
                            try:
                                print(f"Trying to reconnect")
                                sock.close()
                                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                                sock.connect((T_SRV, T_PORT))
                            except Exception as e:
                                print(f"Reconnect to IMU server FAIL due to: {e}")
                        idx = 0
                        ll = []
                    # time.sleep(1)
                    # print(poll_interval * 1.0 / 1000.0)
                    time.sleep(poll_interval * 1.0 / 1000.0)
        except KeyboardInterrupt:
            pass

    def __read_sensor_data(self, sensor_name: str, config: SENSOR_SETTING):
        from multiprocessing import Process, Queue
        import os, time, random
        q = Queue()
        proc_write1 = Process(target=self.iimu, args=(q, 0))
        proc_write1.start()
        print('_'*20)

        while True:
            idx = 0
            while not q.empty():
                # result_list.append(queue.get())
                qq = q.get()
                # print('qq', idx, len(qq))
                # print('='*50, q.qsize())
                idx += 1
                self.send(values=qq)
        
            time.sleep(5)

        # imu_handle = self.__sensor_handles[sensor_name]
        # print(imu_handle)
        # sleep_time = 0.01 if config is None else config.time_period_sec
        # SETTINGS_FILE = "RTIMULib"
        # s = RTIMU.Settings(SETTINGS_FILE)
        # imu = RTIMU.RTIMU(s)
        #
        # print("IMU Name: " + imu.IMUName())
        #
        # if (not imu.IMUInit()):
        #     print("IMU Init Failed")
        #     sys.exit(1)
        # else:
        #     print("IMU Init Succeeded")
        #
        # # data_collection offline
        # # import csv
        # # from datetime import datetime
        # # headers = ['acc_x', 'acc_y', 'acc_z', 'gyro_x', 'gyro_y', 'gyro_z', 'mag_x', 'mag_y', 'mag_z', 'roll', 'pitch',
        # #            'yaw', 'q1', 'q2', 'q3', 'q4', 'ts']
        # # f = open('data-imu-'+str(int(time.time()))+'.csv', 'wt')
        # # f_csv = csv.writer(f)
        # # f_csv.writerow(headers)
        # idx = 0
        # rate = 500
        # coll_sec = 0
        #
        # imu.setSlerpPower(0.02)
        # imu.setGyroEnable(True)
        # imu.setAccelEnable(True)
        # imu.setCompassEnable(False)
        # poll_interval = imu.IMUGetPollInterval()
        # try:
        #     while True:
        #         if imu.IMURead():
        #             # x, y, z = imu.getFusionData()
        #             # print("%f %f %f" % (x,y,z))
        #             data = imu.getIMUData()
        #             accel = data['accel']
        #             gyro = data['gyro']
        #             mag = data['compass']
        #             f_post = data['fusionPose']
        #             accl = imu.getAccelResiduals()
        #             # f_qpose = data['fusionQPose']
        #             ts = time.time()
        #             # --------------------------data_collection offline--------------------------
        #             # row = [accel[0], accel[1], accel[2], gyro[0], gyro[1], gyro[2], mag[0], mag[1], mag[2], f_post[0],
        #             #                    f_post[1], f_post[2], f_qpose[0], f_qpose[1], f_qpose[2], f_qpose[3], ts]
        #             # f_csv.writerow(row)
        #             # f.flush()
        #             # --------------------------data_collection offline--------------------------
        #             # print(accel + gyro + mag + f_post + accl)
        #             self.send(values=accel + gyro + mag + f_post + accl)
        #             # fusionPose = data["fusionPose"]
        #             # print(data["fusionQPose"])
        #             # print("r: %f p: %f y: %f" % (math.degrees(fusionPose[0]),
        #             #     math.degrees(fusionPose[1]), math.degrees(fusionPose[2])))
        #             # print(poll_interval*1.0/1000.0)
        #             idx += 1
        #             if idx > rate:
        #                 coll_sec += 1
        #                 print('coll pkg =', rate, 'count=', coll_sec, 'seconds')
        #                 idx = 0
        #             time.sleep(0.001)
        #     # while True:
        #     #     if self.__active_flag_list[sensor_name]:
        #     #         data = imu_handle.getFusionData()
        #     #         print(data)
        #     #         # accel = data['accel']
        #     #         # gyro = data['gyro']
        #     #         # mag = data['compass']
        #     #         # self.send(values=accel + gyro + mag)
        #     #     time.sleep(sleep_time)
        # except KeyboardInterrupt:
        #     pass
