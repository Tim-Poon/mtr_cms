from common.component import Component
from common.event import *
import time
from threading import Thread
from monitor import osutils
import os


# note: used to redirect to stdout, in principle, all the events traffic should be listened by Debug class
class Debug(Component):
    def __init__(self):
        super().__init__()
        # self.add_event_listener(SensorEvent._event_type, self.print_data)  # from SensorManager
        self.add_event_listener(LogEvent._event_type, self.print_data)  # todo: from all components, except for router?
        # self.add_event_listener("data_backup", self.print_data)  # from Network
        # self.add_event_listener("resend_success", self.print_data)  # from Network
        # self.add_event_listener("resend_data", self.print_data)  # from BackUpSystem
        self.add_event_listener(ResultEvent._event_type, self.print_data)  # from Estimator
        self.add_event_listener(SystemStatusEvent._event_type, self.print_data)  # from SystemMonitor
        self.add_event_listener(HCIStatusEvent._event_type, self.print_data)  # from SystemMonitor
        # self.add_event_listener("sensor_pause", self.print_data)  # todo: from Network or hci
        # self.add_event_listener(RemoteRequestIdEvent._event_type, self.print_data)
        self.add_event_listener(StepEvent._event_type, self.print_data)  # from StepEstimator
        self.add_event_listener(PositionEvent._event_type, self.print_data)  # from StepEstimator
        self.add_event_listener(PositionVelocityEvent._event_type, self.print_data)  # from StepEstimator

    def start(self):
        Thread(target=self.system_self_check).start()

    def print_data(self, e: Event):
        print(f"{time.time()} {e} debugmodule recvtime")

    def system_self_check(self):
        while True:
            print(f"system_self_check: {self.check_program_memory()} mb, {osutils.get_CPU_temperature()} degree")
            time.sleep(10)

    def check_program_memory(self):
        # note: just for checking memory leakage and other system thing stuff, but depends on psutil
        # import psutil
        # process = psutil.Process(os.getpid())
        # return process.memory_info().rss / (1024 ** 2)  # in mega bytes
        pass
