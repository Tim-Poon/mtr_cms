import sys
import struct
import bluetooth._bluetooth as bluez

OGF_LE_CTL=0x08
OCF_LE_SET_SCAN_ENABLE=0x000C

def hci_enable_le_scan(sock):
    hci_toggle_le_scan(sock, 0x01)

def hci_disable_le_scan(sock):
    hci_toggle_le_scan(sock, 0x00)

def hci_toggle_le_scan(sock, enable):
    cmd_pkt = struct.pack("<BB", enable, 0x00)
    bluez.hci_send_cmd(sock, OGF_LE_CTL, OCF_LE_SET_SCAN_ENABLE, cmd_pkt)

def packetToString(packet):
    """
    Returns the string representation of a raw HCI packet.
    """
    if sys.version_info > (3, 0):
        return ''.join('%02x' % struct.unpack("B", bytes([x]))[0] for x in packet)
    else:
        return ''.join('%02x' % struct.unpack("B", x)[0] for x in packet)

def parse_events(sock, loop_count=100):
    old_filter = sock.getsockopt( bluez.SOL_HCI, bluez.HCI_FILTER, 14)
    flt = bluez.hci_filter_new()
    bluez.hci_filter_all_events(flt)
    bluez.hci_filter_set_ptype(flt, bluez.HCI_EVENT_PKT)
    sock.setsockopt( bluez.SOL_HCI, bluez.HCI_FILTER, flt )
    results = []
    for i in range(0, loop_count):
        packet = sock.recv(255)

        ptype, event, plen = struct.unpack("BBB", packet[:3])
        packetOffset = 0
        dataString = packetToString(packet)
        """
        If the bluetooth device is an beacon then show the beacon.
        """
        #print (dataString)
        if (dataString[34:42] == '0303aafe') and (dataString[44:50] == '16AAFE'):
            """
            Selects parts of the bluetooth packets.
            """
            broadcastType = dataString[50:52]
            if broadcastType == '00' :
                type = "Eddystone UID"
                namespace = dataString[54:74].upper()
                instance = dataString[74:86].upper()
                resultsArray = [
                {"type": type, "namespace": namespace, "instance": instance}]
                return resultsArray

            elif broadcastType == '10':
                type = "Eddystone URL"
                urlprefix = dataString[54:56]
                if urlprefix == '00':
                    prefix = 'http://www.'
                elif urlprefix == '01':
                    prefix = 'https://www.'
                elif urlprefix == '02':
                    prefix = 'http://'
                elif urlprefix == '03':
                    prefix = 'https://'
                hexUrl = dataString[56:][:-2]
                if sys.version_info[0] == 3:
                    url = prefix + bytes.fromhex(hexUrl).decode('utf-8')
                    rssi, = struct.unpack("b", bytes([packet[packetOffset-1]]))
                else:
                    url = prefix + hexUrl.decode("hex")
                    rssi, = struct.unpack("b", packet[packetOffset-1])
                resultsArray = [{"type": type, "url": url}]
                return resultsArray

            elif broadcastType == '20':
                type = "Eddystone TLM"
                resultsArray = [{"type": type}]
                return resultsArray

            elif broadcastType == '30':
                type = "Eddystone EID"
                resultsArray = [{"type": type}]
                return resultsArray

            elif broadcastType == '40':
                type = "Eddystone RESERVED"
                resultsArray = [{"type": type}]
                return resultsArray

        if dataString[38:46] == '4c000215':
            """
            Selects parts of the bluetooth packets.
            """
            type = "iBeacon"
            uuid = dataString[46:54] + "-" + dataString[54:58] + "-" + dataString[58:62] + "-" + dataString[62:66] + "-" + dataString[66:78]
            major = dataString[78:82]
            minor = dataString[82:86]
            majorVal = int("".join(major.split()[::-1]), 16)
            minorVal = int("".join(minor.split()[::-1]), 16)
            """
            Organises Mac Address to display properly
            """
            scrambledAddress = dataString[14:26]
            fixStructure = iter("".join(reversed([scrambledAddress[i:i+2] for i in range(0, len(scrambledAddress), 2)])))
            macAddress = ':'.join(a+b for a,b in zip(fixStructure, fixStructure))
            if sys.version_info[0] == 3:
                rssi, = struct.unpack("b", bytes([packet[packetOffset-1]]))
            else:
                rssi, = struct.unpack("b", packet[packetOffset-1])

            resultsArray = [{"type": type, "uuid": uuid, "major": majorVal, "minor": minorVal, "rssi": rssi, "macAddress": macAddress,"raw": dataString[38:88]}]
            return resultsArray

        if dataString[38:46] == 'aafe1116' and '043e2502010001' in dataString:
            # sample
            # 043e2a02010001 f5dfcec453c9 1e0201061aff4c000215 7045de25939e4c3b96174e143f3c78fd 7abd 2716 c5 b8
            # 043e2502010001 f5dfcec453c9 190201060303aafe1116 aafe 20 00 0c1e 1d00 04f83d12 18eb3c6b bf
            # 043e2502010001 f5dfcec453c9 19 02 01 06 03 03 aafe 11 16 aafe 20 00 0c1e 1d00 04f83d2b 18eb3c85 be
            scrambledAddress = dataString[14:26]
            fixStructure = iter("".join(reversed([scrambledAddress[i:i+2] for i in range(0, len(scrambledAddress), 2)])))
            macAddress = ':'.join(a+b for a,b in zip(fixStructure, fixStructure))
            battery = dataString[54:58]
            mvolts = int("".join(battery.split()[::-1]), 16)

            if mvolts >= 3000:                                             
                battery_level = 100
            elif mvolts > 2900:
                battery_level = 100 - ((3000 - mvolts) * 58) / 100
            elif mvolts > 2740:
                battery_level = 42 - ((2900 - mvolts) * 24) / 160
            elif mvolts > 2440:
                battery_level = 18 - ((2740 - mvolts) * 12) / 300                                          
            elif mvolts > 2100:
                battery_level = 6 - ((2440 - mvolts) * 6) / 340
            else:                                      
                battery_level = 0

            resultsArray = [{"type": 'bty', "macAddress": macAddress, "level": battery_level}]
            # return (macAddress, battery_level)
            return resultsArray
    return results