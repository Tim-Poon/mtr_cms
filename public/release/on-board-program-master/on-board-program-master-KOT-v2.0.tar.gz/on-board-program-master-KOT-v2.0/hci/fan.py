import RPi.GPIO as GPIO

try:
	import conf
except:
	import hci.conf as conf
import time
import threading


class FAN(threading.Thread):
	def __init__(self, threadID, name, counter, temperature, conf, fan_pwm):
		threading.Thread.__init__(self)
		self.threadID = threadID
		self.name = name
		self.counter = counter
		self.temperature = temperature
		self.conf = conf
		self.fan_pwm = fan_pwm

	# def run(self):
	# 	GPIO.setwarnings(False)
	# 	GPIO.setmode(GPIO.BOARD)
	# 	GPIO.setup(conf.fan_pin, GPIO.OUT, initial=GPIO.LOW)
	# 	fan = GPIO.PWM(conf.fan_pin, conf.PWM_freq)
	# 	setFanSpeed(conf.fan_off)
	# 	# Handle fan speed every WAIT_TIME sec
	# 	while True:
	# 		control_fan_speed(temperature)
	# 		time.sleep(conf.wait_time)
	def run(self):
		fan_control(self.temperature, self.conf, self.fan_pwm)
	# Set fan


def fan_control(temperature, conf, fan_pwm):
	def setFanSpeed(speed, fan):
		fan.start(speed)
		return ()

	# Control fan speed
	def control_fan_speed(temperature):
		if temperature < conf.min_temp:  # Turn off the fan if temperature is below MIN_TEMP
			setFanSpeed(conf.fan_off, fan)

		elif temperature > conf.max_temp:  # Set fan speed to MAXIMUM if the temperature is above MAX_TEMP
			setFanSpeed(conf.fan_on, fan)
		else:
			step = float(conf.fan_high_speed - conf.fan_low_speed) / float(conf.max_temp - conf.min_temp)
			temperature -= conf.min_temp
			setFanSpeed(conf.fan_low_speed + (round(temperature) * step), fan)
		return ()
	# Setup GPIO pin
	GPIO.setwarnings(False)
	GPIO.setmode(GPIO.BOARD)
	#GPIO.setup(conf.fan_pin, GPIO.OUT, initial=GPIO.LOW)
	#fan = GPIO.PWM(conf.fan_pin, conf.PWM_freq)
	fan = fan_pwm
	setFanSpeed(conf.fan_off, fan)
	# Handle fan speed every WAIT_TIME sec
	while True:
		control_fan_speed(temperature)
		time.sleep(conf.wait_time)

# def fan_control(temperature, conf):
# 	# Set fan speed
# 	def setFanSpeed(speed):
# 		fan.start(speed)
# 		return ()
#
# 	# Control fan speed
# 	def control_fan_speed(temperature):
# 		if temperature < conf.min_temp:  # Turn off the fan if temperature is below MIN_TEMP
# 			setFanSpeed(conf.fan_off)
#
# 		elif temperature > conf.max_temp:  # Set fan speed to MAXIMUM if the temperature is above MAX_TEMP
# 			setFanSpeed(conf.fan_on)
# 		else:
# 			step = float(conf.fan_high_speed - conf.fan_low_speed) / float(conf.max_temp - conf.min_temp)
# 			temperature -= conf.min_temp
# 			setFanSpeed(conf.fan_low_speed + (round(temperature) * step))
# 		return ()
# 	# Setup GPIO pin
# 	GPIO.setwarnings(False)
# 	GPIO.setmode(GPIO.BOARD)
# 	GPIO.setup(conf.fan_pin, GPIO.OUT, initial=GPIO.LOW)
# 	fan = GPIO.PWM(conf.fan_pin, conf.PWM_freq)
# 	setFanSpeed(conf.fan_off)
# 	# Handle fan speed every WAIT_TIME sec
# 	while True:
# 		control_fan_speed(temperature)
# 		time.sleep
if __name__ == '__main__':
	CPU_temperature_final = 55
	FAN(2, "fan_on", 2, CPU_temperature_final, conf).start()
