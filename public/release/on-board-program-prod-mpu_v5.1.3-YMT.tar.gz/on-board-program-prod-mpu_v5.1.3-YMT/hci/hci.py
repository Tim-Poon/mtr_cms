import hci.led as led
import hci.conf as conf
import RPi.GPIO as GPIO
import time
from common.component import Component
from threading import Thread
from common.event import *
from config.common import PI_BLE_MAC_ADDR
import threading
import hci.speaker as speaker
import hci.button as button
import hci.fan as fan
from collections import defaultdict
import os
class HCI(Component):
    def __init__(self):
        super().__init__()
        self.led_pins = [11,13,15,16,18,22]
        self.add_event_publisher(HCIStatusEvent._event_type)
        self.add_event_listener(SystemStatusEvent._event_type, self._visualization_systemstatus)
        self.gpio_initialization()
        #self.pwm_led_list = [GPIO.PWM(conf.LED_PINS["GREEN_LED"].pin, conf.LED_PARAMS["LED_PWM"]),GPIO.PWM(conf.LED_PINS["RED_LED"].pin, conf.LED_PARAMS["LED_PWM"])]
        #self.pwm_initialization()
        self.add_event_listener(ResultEvent._event_type, self.alarm)
        self.add_event_listener(StepAlarmEvent._event_type, self.alarm)
        self.add_event_listener('send_result', self._visualization_send_result)
        self.alarm_status = defaultdict(float)
        self.led_status_dict = {"ORANGE_LED": False, "WHITE_LED": False, "YELLOW_LED": False, "BLUE_LED": False, "GREEN_LED": False, "RED_LED": False}
        # speaker.speaker(conf.SPEAKER_PARAMS['SPEAKER_PIN'], 2, 0.2)

    def start(self):
        Thread(target=self._button_control).start()
        Thread(target=self._fan_start).start()

    def gpio_initialization(self):
        GPIO.setmode(GPIO.BOARD)  # setup the board mode
        for led_color, led_info in conf.LED_PINS.items():
            GPIO.setup(led_info.pin, GPIO.OUT)
            GPIO.output(led_info.pin, False)
        self.led_effect_loops(self.led_pins, 3, 0.05)
        self.led_effect_flash_all(self.led_pins, 6, 0.2)


    @ staticmethod
    def led_effect_flash_all(led_pins, counter, gap):
        i = 0
        while i < counter:
            for pin in led_pins:
                GPIO.output(pin, True)
            time.sleep(gap)
            for pin in led_pins:
                GPIO.output(pin, False)
            time.sleep(gap)
            i+=1


    @ staticmethod
    def led_effect_loops(led_pins, counter, gap):
        i = 0
        for pin in led_pins:
            GPIO.output(pin, False)
        while i <= counter:
            for pin in led_pins:
                GPIO.output(pin, True)
                time.sleep(gap)
                GPIO.output(pin, False)
            for pin in list(reversed(led_pins)):
                GPIO.output(pin, True)
                time.sleep(gap)
                GPIO.output(pin, False)
            i += 1

    def alarm(self, event: ResultEvent):
        if isinstance(event, ResultEvent) and event.value.overspeed_alarm > 0:
            speaker.speaker(conf.SPEAKER_PARAMS['SPEAKER_PIN'], conf.SPEAKER_PARAMS['SPEAKER_LOOP'], conf.SPEAKER_PARAMS['SPEAKER_TIME_INTERVAL'])
            self.led_status_dict['ORANGE_LED'] = True
            led.led_control(conf.LED_PINS['ORANGE_LED'].pin, True)
            self.publish(HCIStatusEvent(identifier=PI_BLE_MAC_ADDR, value=self.led_status_dict))

    def _visualization_send_result(self, event: Event):
        send_result = event._value
        if send_result['rc'] != 0:
            Thread(target=self._led_effect_flash, args=(conf.LED_PINS["WHITE_LED"].pin, 4, 1, 1)).start()
        else:
            GPIO.output(conf.LED_PINS["WHITE_LED"].pin, True)
            if send_result['send'] == 1:
                Thread(target=self._led_effect_flash, args=(conf.LED_PINS["WHITE_LED"].pin, 4, 0.05, 1)).start()



    def _visualization_systemstatus(self, event: Event):
        Thread(target=self._led_effect_flash, args=(conf.LED_PINS["GREEN_LED"].pin, 2, 0.1, 1)).start()
        sensor_status = event.status_dict
        network_status = sensor_status['network_status']
        if network_status:
            GPIO.output(conf.LED_PINS["BLUE_LED"].pin, False)
            Thread(target=self._led_effect_flash, args=(conf.LED_PINS["BLUE_LED"].pin, 4, 0.05, True)).start()
        else:
            GPIO.output(conf.LED_PINS["BLUE_LED"].pin, False)
            # Thread(target=self._led_effect_flash, args=(conf.LED_PINS["BLUE_LED"].pin, 4, 1, False)).start()


        # if event.event_type == SystemStatusEvent._event_type:
        # 	status_dict = event.status_dict
        # 	pi_voltage_information = status_dict['pi_V']
        # 	pi_voltage_processed = str(pi_voltage_information).replace("throttled=", "")
        # 	pi_voltage_final = str(pi_voltage_processed).replace("\n", "")
        # 	if led.under_voltage_detection(list(bin(int(pi_voltage_final, 16)))):
        # 		self.led_status_dict['RED_LED'] = True
        # 		led.led_control(conf.LED_PINS['RED_LED'].pin, True)
        self.publish(HCIStatusEvent(identifier=PI_BLE_MAC_ADDR, value=self.led_status_dict))

    @ staticmethod
    def _led_effect_flash(pin, count, speed, keep):
        led.led_flash(pin, count, speed, keep)

    def _fan_start(self):
        fan.fan_control(conf)

    def _button_control(self):
        final_led_status_dict = button.button_control(self.led_status_dict)
        self.publish(HCIStatusEvent(identifier=PI_BLE_MAC_ADDR, value=final_led_status_dict))
