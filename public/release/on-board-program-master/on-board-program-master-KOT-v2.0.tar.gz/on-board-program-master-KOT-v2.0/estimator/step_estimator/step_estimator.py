from typing import cast
from common.component import Component
from threading import Thread
from common.event import *
import time
from config.common import PI_BLE_MAC_ADDR
from common.data_type import *
from collections import defaultdict
from multiprocessing import Pool
from ._estimate_step import estimate_num_of_step
from collections import deque
from copy import deepcopy


# todo: bind it to site?
STEP_ESTIMATOR_MODULE_PARAMS = {
    'STEP_ESTIMATOR_CAL_PERIOD': 2,
    'WINDOW_SIZE': 5,
}


class StepEstimator(Component):
    def __init__(self):
        super().__init__()
        self.add_event_publisher(StepEvent._event_type)
        self.add_event_listener(SensorEvent._event_type, self.on_receive_sensor_data)  # note: don't know why it warns
        self._acc_records = defaultdict(list)  # {identifier: List[Tuple[TS, ACC_X, ACC_Y, ACC_Z]]]}
        self._step_estimator_pool = Pool(processes=2)

    def start(self):
        Thread(target=self.poll_imu_data).start()

    def poll_imu_data(self):
        cal_period = STEP_ESTIMATOR_MODULE_PARAMS['STEP_ESTIMATOR_CAL_PERIOD']
        time.sleep(cal_period)
        while True:
            for target_identifier, data in self._acc_records.items():
                acce_datas = deepcopy(data)
                s_ts = time.time()
                try:
                    self._step_estimator_pool.apply_async(estimate_num_of_step,
                                                          (acce_datas,),
                                                          callback=self.publish_step_event)
                except:
                    print('error')
                e_ts = time.time()
                # print(f'#imu pack={len(acce_datas)}, pass in pool time={e_ts - s_ts}')
                # print(f'oldest ts = {acce_datas[0][0]}, latest ts = {acce_datas[-1][0]}, ')
            time.sleep(cal_period)

    def on_receive_sensor_data(self, event: SensorEvent):
        if isinstance(event.value, IMUDataPackage):
            self._on_receive_imu_data(cast(IMUDataPackage, event.value))

    def _on_receive_imu_data(self, imu_data_package: IMUDataPackage):
        target_identifier = imu_data_package.target_identifier
        # todo: need lock
        window_size = STEP_ESTIMATOR_MODULE_PARAMS['WINDOW_SIZE']

        acce_datas = self._acc_records[target_identifier]
        cur_ts = imu_data_package.timestamp * 1000
        if acce_datas:
            valid_idx = 0
            for acc_data in acce_datas:
                if cur_ts - acc_data[0] > window_size * 1000:
                    valid_idx += 1
                else:
                    break
            # print(valid_idx)
            # print('before', self._acc_records[target_identifier])
            acce_datas = acce_datas[valid_idx:]
            # print('after', self._acc_records[target_identifier])
        acce_datas.append((cur_ts,
                           imu_data_package.value.acc_x * 9.81,
                           imu_data_package.value.acc_y * 9.81,
                           imu_data_package.value.acc_z * 9.81,
                           ))
        self._acc_records[target_identifier] = acce_datas
        # delta_t = (acce_datas[-1][0] - acce_datas[0][0])
        # if delta_t > STEP_ESTIMATOR_MODULE_PARAMS['STEP_ESTIMATOR_CAL_PERIOD']:
        #     s_ts = time.time()
        #     try:
        #         self._step_estimator_pool.apply_async(estimate_num_of_step,
        #                                               (acce_datas, ),
        #                                               callback=self.estimate_overspeed)
        #     except:
        #         print('error')
        #     else:
        #         e_ts = time.time()
        #         print(f'in {delta_t}s #imu pack={len(acce_datas)}, pass in pool time={e_ts-s_ts}')
        #     finally:
        #         self._acc_records[target_identifier] = []
        #         del acce_datas

    def publish_step_event(self, step):
        self.publish(StepEvent(identifier=PI_BLE_MAC_ADDR,
                               value=step))

    # def estimate_overspeed(self,
    #                        step):
    #     self._history_step.append(step)
    #     print(f'#step = {step}')
    #     alarm = True if step > STEP_ESTIMATOR_MODULE_PARAMS['STEP_ALARM_THRESHOLD'] else False
    #     self.publish(StepAlarmEvent(identifier=PI_BLE_MAC_ADDR,
    #                                 step=step,
    #                                 value=alarm))
