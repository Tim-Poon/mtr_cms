from common.component import Component
from common.router import Router, start_router
from common.event import Event
import time
from multiprocessing import Process


class TestPublisher(Component):
    def __init__(self):
        super().__init__()

    def publish(self):
        for i in range(1000):
            self.publish_event(Event("test_log", msg=f"sending {i} at {time.time()}"))
            print(f"send {i}")


class TestSubscriber(Component):
    def __init__(self):
        super().__init__()

    def subscribe(self):
        self.add_event_listener("test_log", event_handler=lambda e: print(e))


if __name__ == "__main__":
    start_router()
    publisher_node = TestPublisher()
    subscribe_node = TestSubscriber()
    p1 = Process(target=publisher_node.publish)
    p2 = Process(target=subscribe_node.subscribe)
    p1.start()
    p2.start()
    p1.join()
    p2.join()

