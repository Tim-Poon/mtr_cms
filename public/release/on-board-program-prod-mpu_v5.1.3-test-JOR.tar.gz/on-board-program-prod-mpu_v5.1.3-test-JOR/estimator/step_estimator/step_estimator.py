from typing import cast
from common.component import Component
from threading import Thread
from common.event import *
import time
from config.common import PI_BLE_MAC_ADDR
from common.data_type import *
from collections import defaultdict
from multiprocessing import Pool
from ._estimate_step import estimate_num_of_step
from collections import deque
from copy import deepcopy
from scipy.fftpack import fft, ifft, fftfreq
import numpy as np
from scipy.signal import filtfilt, butter
from random import uniform
import pandas as pd
from scipy.integrate import cumtrapz
from scipy.signal import find_peaks
from config.common import SENSOR_SITE, PI_BLE_MAC_ADDR
import importlib
# todo: bind it to site?
STEP_ESTIMATOR_MODULE_PARAMS = {
    'STEP_ESTIMATOR_CAL_PERIOD': 2,
    'WINDOW_SIZE': 5,
}


class StepEstimator(Component):
    def __init__(self):
        super().__init__()
        self.add_event_publisher(StepEvent._event_type)
        self.add_event_listener(SensorEvent._event_type, self.on_receive_sensor_data)  # note: don't know why it warns
        self._acc_records = defaultdict(list)  # {identifier: List[Tuple[TS, ACC_X, ACC_Y, ACC_Z]]]}
        # self._step_estimator_pool = Pool(processes=2)
        self.last_g = []
        self.r_time = time.time()
        self.last_raw_data = pd.DataFrame()

        self.site = SENSOR_SITE
        self.__site_config = self._load_config(self.site)


    def _load_config(self, site):
        try:
            site_config = importlib.import_module(name=f'config.{site}')
        except Exception as err:
            self.publish(LogEvent(identifier=PI_BLE_MAC_ADDR,
                                  value=LogMessage(level='error',
                                                   msg=f"unable to load config for core: {traceback.format_exc()}")))
            return None
        return site_config


    def start(self):
        pass
        # Thread(target=self.poll_imu_data).start()

    def poll_imu_data(self):
        cal_period = STEP_ESTIMATOR_MODULE_PARAMS['STEP_ESTIMATOR_CAL_PERIOD']
        time.sleep(cal_period)
        while True:
            for target_identifier, data in self._acc_records.items():
                acce_datas = deepcopy(data)
                s_ts = time.time()
                try:
                    self._step_estimator_pool.apply_async(estimate_num_of_step,
                                                          (acce_datas,),
                                                          callback=self.publish_step_event)
                except:
                    print('error')
                e_ts = time.time()
                # print(f'-------------------# imu_pack = {len(acce_datas)}')
                # print(f'oldest ts = {acce_datas[0][0]}, latest ts = {acce_datas[-1][0]}, ')
            time.sleep(cal_period)

    def on_receive_sensor_data(self, event: SensorEvent):
        if isinstance(event.value, IMUDataPackage):
            self._on_receive_imu_data(cast(IMUDataPackage, event.value))

    def pedometer(self, fs):
        # TODO relate to frequency!
        # ARG_FEQ = 80 # 20 | 40 | 80 | 250 | 500
        ARG_STEP_G = 0.15 # seconds
        ARG_STEP_MAX_TIME = 1.5 # seconds
        ARG_STEP_MIN_TIME = 0.4 # seconds
        ARG_STEP_JUMP_TIME = 2 # seconds

        acc_g_nrom = np.array(self.last_raw_data['acc'] - self.last_raw_data['acc'].mean())

        b, a = butter(3, 8/fs, 'low')
        acc_norm_low_pass = filtfilt(b, a, acc_g_nrom)
        
        ts = self.last_raw_data.ts
        ts = ts.reset_index(drop=True)
        init_ts = 0
        step_flag = 0
        step = 0
        for idx, g in enumerate(acc_norm_low_pass):
            if g > ARG_STEP_G and step_flag == 0:
                step_flag = 1
                if ts[idx] - init_ts < ARG_STEP_MAX_TIME:
                    step += 1
                init_ts = ts[idx]
            if ts[idx] - init_ts > ARG_STEP_MIN_TIME and step_flag == 1:
                step_flag = 0
            elif ts[idx] - init_ts > ARG_STEP_JUMP_TIME:
                step_flag = 0
        
        return step

    def find_tactile(self, fs):
        # self.last_raw_data
        acc_g_nrom = np.array(self.last_raw_data['acc'] - self.last_raw_data['acc'].mean())
        pass_tactile = 0
    
        ARG_TACTILE_MAX_GAP = 0.20 # s
        ARG_TACTILE_MIN_GAP = 0.04 # s
        ARG_TACTILE_MIN_PEAKS = 3 # 5 peaks
        ARG_TACTILE_MIN_LEVEL = 4 # times with mean
        ARG_TACTILE_MIN = 0.2 # g

        ARG_TACTILE_LOWPASS = 0.3 # lowpass/raw

        # get peak distance (filter according to max_gap * frequency)
        def get_distance(peaks, max_gap, fs):
            dist_peaks = []
            idx = 1
            max_peak = []
            peak_coor = [-1, -1]
            while idx < len(peaks):
                dist = peaks[idx] - peaks[idx-1]
                # print(dist)
                if dist < max_gap * fs:
                    if peak_coor[0] == -1:
                        peak_coor[0] = idx
                    else:
                        peak_coor[1] = idx
                elif peak_coor[0] != -1:
                    # print('P', peak_coor[1] - peak_coor[0])
                    if peak_coor[1] - peak_coor[0] >= ARG_TACTILE_MIN_PEAKS:
                        max_peak.append(peak_coor)
                    peak_coor = [-1, -1]
                idx += 1
            if peak_coor[0] != -1:
                # print('P', peak_coor[1] - peak_coor[0])
                if peak_coor[1] - peak_coor[0] >= ARG_TACTILE_MIN_PEAKS:
                    max_peak.append(peak_coor)
            return max_peak

        if np.std(acc_g_nrom) > ARG_TACTILE_MIN:
            raw_peaks, d = find_peaks(acc_g_nrom, height=np.std(acc_g_nrom), distance=ARG_TACTILE_MIN_GAP * fs)
            # peaks_mean, peaks_len = get_distance(raw_peaks, ARG_TACTILE_MAX_GAP, fs)
            max_peak = get_distance(raw_peaks, ARG_TACTILE_MAX_GAP, fs)
            # print(raw_peaks)
            if len(max_peak) > 0:
                pass_tactile = []
                for i in max_peak:
                    b, a = butter(10, .06, 'low')
                    # check_decay = raw_data[raw_peaks[i[0]]:raw_peaks[i[1]]]
                    g_lp = filtfilt(b, a, acc_g_nrom)
                    # print(f"raw={len(raw_peaks)}, n_peaks={len(max_peak)}, avg_gap={max_peak} (threshold={ARG_TACTILE_MAX_GAP * fs:.2f})")
                    # print(np.std(g_lp)/np.std(acc_g_nrom) , ARG_TACTILE_LOWPASS)
                    if np.std(g_lp)/np.std(acc_g_nrom) > ARG_TACTILE_LOWPASS:
                        # print(f'{len(max_peak)}, {np.std(raw_data):.2f} [{raw_data.loc[raw_peaks[i[0]]].ts}, {raw_data.loc[raw_peaks[i[1]]].ts}]')
                        pass_tactile.append([self.last_raw_data.loc[raw_peaks[i[0]]].ts, self.last_raw_data.loc[raw_peaks[i[1]]].ts])
                if len(pass_tactile) == 0:
                    pass_tactile = 0
        return pass_tactile

    def _on_receive_imu_data(self, imu_data_package: IMUDataPackage):


        target_identifier = imu_data_package.target_identifier
        # todo: need lock
        # window_size = STEP_ESTIMATOR_MODULE_PARAMS['WINDOW_SIZE']

        # acce_datas = self._acc_records[target_identifier]
        # print(f"step ---- {(imu_data_package._value.mpu[0])}")
        # raw_data = pd.DataFrame(imu_data_package._value.mpu, columns=['ts', 'g', 'accl_x', 'accl_y', 'accl_z'])
        raw_data = pd.DataFrame(imu_data_package._value.mpu, columns=['ts', 'acc', 'accl', 'gyro'])
        # append new raw data
        self.last_raw_data = pd.concat([self.last_raw_data, raw_data])
        # filter by sliding window
        self.last_raw_data = self.last_raw_data[self.last_raw_data['ts'] > (time.time() - 4)]
        self.last_raw_data = self.last_raw_data.reset_index(drop=True)
        fs = 250

        window_speed = 0
        step = 0
        tactile = False
        cum_speed = 0

        b, a = butter(4, .5, 'low', fs=fs)
        accl_low_pass = filtfilt(b, a, self.last_raw_data['accl'])
        # print(accl_low_pass)
        try:
            acc_g_std = self.last_raw_data['acc'].std()

            gyro_g_std = self.last_raw_data['gyro'].std()
            # print(self.last_raw_data['gyro'])
            acc_g_nrom = 0
            if acc_g_std > 0.01:
                acc_g_nrom = np.array(self.last_raw_data['acc'] - self.last_raw_data['acc'].mean())
                g_std = round(np.std(acc_g_nrom), 2)
                # print(acc_g_nrom)
                if acc_g_std < 0.8:
                    tactile = self.find_tactile(fs)
                    # print(tactile)
                    if tactile:
                        tactile = True
                        window_speed = 0.89
                    else:
                        step = self.pedometer(fs)
                        cum_speed = cumtrapz(np.multiply(accl_low_pass,1), x=self.last_raw_data['ts'])
                        cum_speed = round(cum_speed[-1], 2)
                        alarm_th = 0.6
                        if self.__site_config.VELOCITY_MODULE_PARAMS['2.0_ALARM_TH']:
                            alarm_th = self.__site_config.VELOCITY_MODULE_PARAMS['2.0_ALARM_TH']
                        if step:
                            # slow [0.75, 0.88]
                            window_speed = 0.2
                            if step > 3:
                                window_speed = round(step * 0.7 / 4, 2)
                                window_speed = 0.9
                            if step >= 8:
                                window_speed = 0.9
                        else:
                            window_speed = cum_speed
                            # Diamond Hii
                            # if window_speed > 0.35 and g_std < 0.2 and gyro_g_std < .5:
                            #     window_speed = 1.3
                            # YMT
                            if window_speed > alarm_th and g_std < 0.2 and gyro_g_std < .5:
                                window_speed = 1.3

                            elif gyro_g_std > .5:
                                if window_speed > 0.58 and g_std < 0.5:
                                    window_speed = 1.3
                            if gyro_g_std > 1:
                                window_speed = 0.89

                            

                            # if cum_speed > 2:
                            #     window_speed = 1.8
                            # test = cumtrapz(np.multiply(self.last_raw_data['accl'],1), x=self.last_raw_data['ts'])
                else:
                    window_speed = 1.3

            print('window_speed =', window_speed, 'cum_speed', cum_speed, 'step', step, 'tactile', tactile, 'std', round(acc_g_std, 2), round(gyro_g_std, 2))
            self.publish_step_event(window_speed)
        except Exception as e:
            print('e', e)
        


        #------------------backup
        # raw_data = np.array(imu_data_package._value.mpu)
        # print(len(raw_data),len(self.last_g))
        # if len(self.last_g) == 0:
        #     self.last_g = raw_data
        
        # raw_data_full = np.append(raw_data, self.last_g)
        # self.last_g = raw_data
        # # raw_data_full = raw_data
        # feq = len(raw_data_full)/5

        # # rr_t = time.time()
        # # print(len(raw_data_full), rr_t-self.r_time)
        # # self.r_time = rr_t
        

        # b, a = butter(3, 8/feq, 'low') # 0.04=0.2*2/10, magic num 0.2
        # raw_data_lp = filtfilt(b, a, raw_data_full-np.mean(raw_data_full))
        # # print(imu_data_package._value.mpu)
        # gg = []
        # for g in raw_data_full:
        #     if g <0.8 or g>1.2:
        #         gg.append(0)
        #     else:
        #         gg.append(1)

        # ARG_STEP_G = 0.15 # g
        # step_flag = 0
        # step_v1 = 0
        # init_idx = 0
        # for idx, g in enumerate(raw_data_lp):
        #     if g > ARG_STEP_G and step_flag == 0:
        #         step_flag = 1
        #         if idx - init_idx < feq * 1.5:
        #             step_v1 += 1
        #         init_idx = idx
        #     if idx - init_idx > feq * 0.4 and step_flag == 1:
        #         step_flag = 0
        #     elif idx - init_idx > feq * 2:
        #         step_flag = 0



        # fft_y = fft(raw_data_full)
        # # print(fft_y)
        # data_len = len(raw_data_full)
        # fft_y = np.abs(fft_y)
        # nfft_y = fft_y/data_len
        # nfft_y = nfft_y[range(int(data_len/2))]

        # y = fftfreq(data_len, 1/feq)[:data_len//2]

        # y_limit = np.where((y < 3) & (y > 0.2))
        # nfft_y_limit = nfft_y[y_limit[0][0]:y_limit[0][-1]]
        # max_id = np.argwhere(nfft_y_limit==max(nfft_y_limit))[0][0] + y_limit[0][0]
        
        # step = 0
        # # print(nfft_y)
        # st = np.mean(nfft_y[1:])/nfft_y[max_id]
        # # st = raw_data_full.var()
        # # if nfft_y[max_id] > 0.01 and y[max_id] < 3 and st > 0.001:
        # if nfft_y[max_id] > 0.01 and st < 0.25:
        #     step = int(y[max_id]*5)

        # # print('-'*60, f"step={step}/{step_v1}, st={int(st * 100)}% feq={feq} ")

        # vel_step = ((step_v1))/5*0.7
        # vel_acc = np.mean(gg)
        # general = 0
        # r_seed = uniform(-0.1, 0.1)
        # if vel_acc > 0.9 and vel_step < 0.3:
        #     general = 0.2 + r_seed
        # elif vel_step >  0.8:
        #     general = vel_step
        # else:
        #     general = -1

        # # print(f'---------------------------------------------------------------general={general}, vel_acc={vel_acc}, vel_step={vel_step:.2f}, step={step}/{step_v1}')
        # self.publish_step_event(round(general,2))
        # public imu speed
        # self.publish_step_event(int(step+step_v1)/2)
        #------------------backup


        # cur_ts = imu_data_package.timestamp * 1000
        # if acce_datas:
        #     valid_idx = 0
        #     for acc_data in acce_datas:
        #         if cur_ts - acc_data[0] > window_size * 1000:
        #             valid_idx += 1
        #         else:
        #             break
        #     # print(valid_idx)
        #     # print('before', self._acc_records[target_identifier])
        #     acce_datas = acce_datas[valid_idx:]
        #     # print('after', self._acc_records[target_identifier])
        # acce_datas.append((cur_ts,
        #                    imu_data_package.value.acc_x * 9.81,
        #                    imu_data_package.value.acc_y * 9.81,
        #                    imu_data_package.value.acc_z * 9.81,
        #                    ))
        # self._acc_records[target_identifier] = acce_datas

    def publish_step_event(self, step):
        # print('-'*10, step)
        self.publish(StepEvent(identifier=PI_BLE_MAC_ADDR,
                               value=step))
