import sys
import os
full_path = os.path.abspath(__file__)
dir_name = os.path.dirname(os.path.dirname(full_path))
sys.path = [dir_name] + sys.path
from common.router import Router
from common.component import Component
import config.common as config
import importlib
from multiprocessing import Process, set_start_method


# note: config should be read only during production
# todo: need to analyse sensor data stream.
# 0. set up debug mode
config.MTR_SERVICE_UUID = "7045de25939e4c3b96174e143f3c78fd"  # beacon UUiD in lab

# 1. select active which IMU sensor(e.g. FAKEIMU and/or MPU9250)
config.SENSOR_LIST = {"test.mock.mock_sensors.mock_imu":    config.SENSOR_SETTING(sensor_type=config.SensorType.SENSOR_IMU, active=True, time_period_sec=0.01),
                      "sensors.imu":                        config.SENSOR_SETTING(sensor_type=config.SensorType.SENSOR_IMU, active=False, time_period_sec=0.01),
                      "test.mock.mock_sensors.mock_ble":    config.SENSOR_SETTING(sensor_type=config.SensorType.SENSOR_BLE, active=True, time_period_sec=0),
                      "sensors.beacon":                     config.SENSOR_SETTING(sensor_type=config.SensorType.SENSOR_BLE, active=False, time_period_sec=0),
                      "test.mock.mock_sensors.mock_wifi":   config.SENSOR_SETTING(sensor_type=config.SensorType.SENSOR_WIFI, active=False, time_period_sec=0.01),
                      "sensors.wifi":                       config.SENSOR_SETTING(sensor_type=config.SensorType.SENSOR_WIFI, active=False, time_period_sec=0.01),
                      }

# 2. only active sensor manager, those in comment is not yet implemented
config.TO_LOAD_MODULES = {"backup.backup": True,
                          "estimator.estimator": False,
                          "sensors.sensor_manager": True,
                          "network.network": True,
                          # "hci.hci": False,
                          "monitor.system_monitor": False,

                          # "test.mock.mock_backup.mock_backup": False,
                          # "test.mock.mock_estimator.mock_estimator": False,
                          # "test.mock.mock_sensors.mock_sensor_manager": True,
                          # "test.mock.mock_network.mock_network": False,
                          # "test.mock.mock_hci.mock_hci": False,
                          "test.mock.mock_monitor.mock_system_monitor": True,

                          "utils.debug": True
                          }

# 3. remote server ip, port
config.SERVER_IP = '127.0.0.1'
config.SERVER_PORT = 5354


# 4. turn on TCP server for testing wherever you like
def start_tcp_server():
    import json
    from utils.security import decrypt

    def callback(byte_msg: bytes, addr: tuple):
        x = json.loads(byte_msg)
        for str_idx, str_msg in x.items():
            event = json.loads(decrypt(bytes(str_msg, encoding='utf-8')))
            print(event)

    from network.tcp import TCPServer
    server = TCPServer(config.SERVER_IP, config.SERVER_PORT)
    server.start(callback=callback)
# Process(target=start_tcp_server).start()


if __name__ == "__main__":
    # note: 1. test whether or not receive data package will be affected or not.
    # note: 2. test stability, including, the unstable network states, crash and recover of threads
    set_start_method('fork')
    Router().loop_forever(daemon=True)
    loaded_modules = []
    for m, flag in config.TO_LOAD_MODULES.items():
        if flag:
            loaded_modules.append(importlib.import_module(name=m))

    for m in Component._components:
        m.start()


