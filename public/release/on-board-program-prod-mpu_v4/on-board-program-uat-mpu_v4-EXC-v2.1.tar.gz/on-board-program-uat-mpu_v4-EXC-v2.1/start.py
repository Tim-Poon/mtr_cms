import sys
import os
full_path = os.path.abspath(__file__)
dir_name = os.path.dirname(full_path)
sys.path = [dir_name] + sys.path
from common.router import Router
from common.component import Component
import config.common as config
import importlib
import atexit
import os
from multiprocessing import Process, Queue
import os, time, random
#
# # todo: inherite multiprocessing manager when writing __router?
#
#
# def start_estimator(sensor_data_queue, estimation_result_queue):
#     pass
#
#
# def start_basic_services(sensor_data_queue, estimation_result_queue):
#     from common.router import Router
#     from monitor.system_monitor import SystemMonitor
#     from sensors.sensor_manager import SensorManager
#
#     # todo: where to do the registration? configuration is the default registration set.
#     # todo: sensor_manager in other process? hard to control sensor manager then?
#     sensor_manager = SensorManager()
#
#     router = Router()  # todo: when will the connection to outside world(db, apiserver, multiprocess-queue) break? Should __router recreate it?
#
#     router_thread = Thread(target=router.loop_forever)
#     router_thread.start()
#
#
#     system_monitor_thread = Thread(target=SystemMonitor().watch, args=(router, ))
#     system_monitor_thread.start()
#
#
# def start_sensor_manager(sensor_data_queue):
#     from sensors.sensor_manager import SensorManager
#     sensor_manager = SensorManager()
#
# # todo: multiprocessing manager
#
#
# if __name__ == "__main__":
#     sensor_data_q = Queue()
#
#     estimator_process = Process(target=start_estimator, args=(sensor_data_q, ))
#     basic_services_process = Process(target=start_basic_services, args=(sensor_data_q,))
#
#     try:
#         while 1:
#             if not estimator_process.is_alive():
#                 estimator_process.start()
#             if not basic_services_process.is_alive():
#                 basic_services_process.start()
#             time.sleep(1)
#     except Exception as e:
#         # todo: pay attention to thread error and process error.
#         pass
def set_feq_file():
    set_feq = os.popen("grep 'i2c_arm_baudrate=1000000' /boot/config.txt")
    set_feq_return = False
    try:
        set_feq_return = set_feq.readlines()[0]
    except:
        pass
    if set_feq_return:
        print('Already set maximun frequency.')
    else:
        print('Setting maximun frequency!')
        set_feq = os.popen("sed -i 's/dtparam=i2c_arm=on/dtparam=i2c_arm=on,i2c_arm_baudrate=1000000/' /boot/config.txt")
        os.popen("reboot")

def on_exit():
    import RPi.GPIO as GPIO
    GPIO.cleanup()
    print('on_exit: exit')


def iimu(q, feq):
    import sensors.RTIMU as RTIMU
    from config.common import PI_BLE_MAC_ADDR
    import socket
    import json
    import zlib

    SETTINGS_FILE = "RTIMULib"
    s = RTIMU.Settings(SETTINGS_FILE)
    imu = RTIMU.RTIMU(s)

    T_SRV = 'mtr-uat-internal.smartsensing.biz'
    T_PORT = 4001

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        sock.connect((T_SRV, T_PORT))
    except Exception as e:
        print(f"Connect to IMU server DOWN due to: {e}")

    print("IMU Name: " + imu.IMUName())

    start_flag = 0
    while not imu.IMUInit():
        print("IMU Init Failed, trying to re-init")
        time.sleep(3)
        s = RTIMU.Settings(SETTINGS_FILE)
        imu = RTIMU.RTIMU(s)
        start_flag += 1
        if start_flag > 10:
            rint("IMU Init DOWN!!!")
            break

    if (not imu.IMUInit()):
        print("IMU Init Failed")
        sys.exit(1)
    else:
        print("IMU Init Succeeded")

    idx = 0
    rate = 500
    coll_sec = 0
    ll = []

    imu.setSlerpPower(0.02)
    imu.setGyroEnable(True)
    imu.setAccelEnable(True)
    imu.setCompassEnable(False)
    poll_interval = imu.IMUGetPollInterval()
    try:
        while True:
            if imu.IMURead():
                data = imu.getIMUData()
                accel = data['accel']
                gyro = data['gyro']
                mag = data['compass']
                f_post = data['fusionPose']
                # accl = imu.getAccelResiduals()
                # self.send(values=accel + gyro + mag + f_post + accl)
                ll.append([PI_BLE_MAC_ADDR,
                           round(accel[0], 4),
                           round(accel[1], 4),
                           round(accel[2], 4),
                           round(gyro[0], 4),
                           round(gyro[1], 4),
                           round(gyro[2], 4),
                           round(mag[0], 4),
                           round(mag[1], 4),
                           round(mag[2], 4),
                           round(f_post[0], 4),
                           round(f_post[1], 4),
                           round(f_post[2], 4),
                           time.time()
                          ])
                idx += 1
                if idx > rate:
                    coll_sec += 1
                    # print('coll pkg =', rate, 'count=', coll_sec, 'seconds')
                    # q.put(ll)
                    pkg = json.dumps(ll).encode('utf-8')
                    compressed_data = zlib.compress(pkg)
                    compressed_data += b'/'
                    print('org pkg =', len(pkg), 'compressed =', len(compressed_data))
                    try:
                        sock.sendall(compressed_data)
                    except Exception as e:
                        print(f"Send IMU data to server FAIL due to: {e}")
                        try:
                            print(f"Trying to reconnect")
                            sock.close()
                            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                            sock.connect((T_SRV, T_PORT))
                        except Exception as e:
                            print(f"Reconnect to IMU server FAIL due to: {e}")
                    idx = 0
                    ll = []
                # time.sleep(1)
                time.sleep(poll_interval * 1.0 / 1000.0)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    update0 = os.popen('sudo dpkg --configure -a')
    print(update0.readlines())
    update1 = os.popen('sudo apt-get install bluetooth libbluetooth-dev -y')
    print(update1.readlines())
    update2 = os.popen('sudo pip3 install pybluez')
    print(update2.readlines())
    set_feq_file()
    # q = Queue()
    # proc_write1 = Process(target=iimu, args=(q, 0))
    # proc_write1.start()
    # imu testing



    Router().loop_forever(daemon=True)
    loaded_modules = []
    for m, flag in config.TO_LOAD_MODULES.items():
        if flag:
            loaded_modules.append(importlib.import_module(name=m))
    
    for m in Component._components:
        m.start()
    
    atexit.register(on_exit)
