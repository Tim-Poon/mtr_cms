# coding: utf-8
## @package MPU9250
#  This is a FaBo9Axis_MPU9250 library for the FaBo 9AXIS I2C Brick.
#
#  http://fabo.io/202.html
#
#  Released under APACHE LICENSE, VERSION 2.0
#
#  http://www.apache.org/licenses/
#
#  FaBo <info@fabo.io>
import time
import sys
from sensors.sensor import Sensor
from threading import Thread, Lock
from config.common import SensorType, SENSOR_SETTING, SENSOR_LIST  # todo: config cross too many layer
from test.mock.mock_sensors.mock_imu import MOCKIMU
import traceback
from functools import partial

## MPU9250 Default I2C slave address
# todo write a easy yet robust small test case to check hardware stuff
SLAVE_ADDRESS = 0x69  # note: 3b is different from 4b, also different board can be different
# SLAVE_ADDRESS = 0x68

## AK8963 I2C slave address
AK8963_SLAVE_ADDRESS = 0x0C

## Device id
DEVICE_ID = 0x71

''' MPU-9250 Register Addresses '''
## sample rate driver
SMPLRT_DIV = 0x19
CONFIG = 0x1A
GYRO_CONFIG = 0x1B
ACCEL_CONFIG = 0x1C
ACCEL_CONFIG_2 = 0x1D
LP_ACCEL_ODR = 0x1E
WOM_THR = 0x1F
FIFO_EN = 0x23
I2C_MST_CTRL = 0x24
I2C_MST_STATUS = 0x36
INT_PIN_CFG = 0x37
INT_ENABLE = 0x38
INT_STATUS = 0x3A
ACCEL_OUT = 0x3B
TEMP_OUT = 0x41
GYRO_OUT = 0x43

I2C_MST_DELAY_CTRL = 0x67
SIGNAL_PATH_RESET = 0x68
MOT_DETECT_CTRL = 0x69
USER_CTRL = 0x6A
PWR_MGMT_1 = 0x6B
PWR_MGMT_2 = 0x6C
FIFO_R_W = 0x74
WHO_AM_I = 0x75

## Gyro Full Scale Select 250dps
GFS_250 = 0x00
## Gyro Full Scale Select 500dps
GFS_500 = 0x01
## Gyro Full Scale Select 1000dps
GFS_1000 = 0x02
## Gyro Full Scale Select 2000dps
GFS_2000 = 0x03
## Accel Full Scale Select 2G
AFS_2G = 0x00
## Accel Full Scale Select 4G
AFS_4G = 0x01
## Accel Full Scale Select 8G
AFS_8G = 0x02
## Accel Full Scale Select 16G
AFS_16G = 0x03

# AK8963 Register Addresses
AK8963_ST1 = 0x02
AK8963_MAGNET_OUT = 0x03
AK8963_CNTL1 = 0x0A
AK8963_CNTL2 = 0x0B
AK8963_ASAX = 0x10

# CNTL1 Mode select
## Power down mode
AK8963_MODE_DOWN = 0x00
## One shot data output
AK8963_MODE_ONE = 0x01

## Continous data output 8Hz
AK8963_MODE_C8HZ = 0x02
## Continous data output 100Hz
AK8963_MODE_C100HZ = 0x06

# Magneto Scale Select
## 14bit output
AK8963_BIT_14 = 0x00
## 16bit output
AK8963_BIT_16 = 0x01

## smbus



## MPU9250 I2C Controll class
class MPU9250:

    ## Constructor
    #  @param [in] address MPU-9250 I2C slave address default:0x68
    def __init__(self, address=SLAVE_ADDRESS, callback=None):

        import smbus  # note: on pi, pay attention to the import path and raspi config
        self.bus = smbus.SMBus(1)
        self.active = False
        self.callback = callback

        self.address = address
        self.configMPU9250(GFS_250, AFS_2G)
        self.configAK8963(AK8963_MODE_C8HZ, AK8963_BIT_16)

    ## Search Device
    #  @param [in] self The object pointer.
    #  @retval true device connected
    #  @retval false device error
    def searchDevice(self):
        who_am_i = self.bus.read_byte_data(self.address, WHO_AM_I)
        if (who_am_i == DEVICE_ID):
            return True
        else:
            return False

    ## Configure MPU-9250
    #  @param [in] self The object pointer.
    #  @param [in] gfs Gyro Full Scale Select(default:GFS_250[+250dps])
    #  @param [in] afs Accel Full Scale Select(default:AFS_2G[2g])
    def configMPU9250(self, gfs, afs):
        if gfs == GFS_250:
            self.gres = 250.0 / 32768.0
        elif gfs == GFS_500:
            self.gres = 500.0 / 32768.0
        elif gfs == GFS_1000:
            self.gres = 1000.0 / 32768.0
        else:  # gfs == GFS_2000
            self.gres = 2000.0 / 32768.0

        if afs == AFS_2G:
            self.ares = 2.0 / 32768.0
        elif afs == AFS_4G:
            self.ares = 4.0 / 32768.0
        elif afs == AFS_8G:
            self.ares = 8.0 / 32768.0
        else:  # afs == AFS_16G:
            self.ares = 16.0 / 32768.0

        # sleep off
        self.bus.write_byte_data(self.address, PWR_MGMT_1, 0x00)
        time.sleep(0.1)
        # auto select clock source
        self.bus.write_byte_data(self.address, PWR_MGMT_1, 0x01)
        time.sleep(0.1)
        # DLPF_CFG
        self.bus.write_byte_data(self.address, CONFIG, 0x03)
        # sample rate divider
        self.bus.write_byte_data(self.address, SMPLRT_DIV, 0x04)
        # gyro full scale select
        self.bus.write_byte_data(self.address, GYRO_CONFIG, gfs << 3)
        # accel full scale select
        self.bus.write_byte_data(self.address, ACCEL_CONFIG, afs << 3)
        # A_DLPFCFG
        self.bus.write_byte_data(self.address, ACCEL_CONFIG_2, 0x03)
        # BYPASS_EN
        self.bus.write_byte_data(self.address, INT_PIN_CFG, 0x02)
        time.sleep(0.1)

    ## Configure AK8963
    #  @param [in] self The object pointer.
    #  @param [in] mode Magneto Mode Select(default:AK8963_MODE_C8HZ[Continous 8Hz])
    #  @param [in] mfs Magneto Scale Select(default:AK8963_BIT_16[16bit])
    def configAK8963(self, mode, mfs):
        if mfs == AK8963_BIT_14:
            self.mres = 4912.0 / 8190.0
        else:  # mfs == AK8963_BIT_16:
            self.mres = 4912.0 / 32760.0

        self.bus.write_byte_data(AK8963_SLAVE_ADDRESS, AK8963_CNTL1, 0x00)
        time.sleep(0.01)

        # set read FuseROM mode
        self.bus.write_byte_data(AK8963_SLAVE_ADDRESS, AK8963_CNTL1, 0x0F)
        time.sleep(0.01)

        # read coef data
        data = self.bus.read_i2c_block_data(AK8963_SLAVE_ADDRESS, AK8963_ASAX, 3)

        self.magXcoef = (data[0] - 128) / 256.0 + 1.0
        self.magYcoef = (data[1] - 128) / 256.0 + 1.0
        self.magZcoef = (data[2] - 128) / 256.0 + 1.0

        # set power down mode
        self.bus.write_byte_data(AK8963_SLAVE_ADDRESS, AK8963_CNTL1, 0x00)
        time.sleep(0.01)

        # set scale&continous mode
        self.bus.write_byte_data(AK8963_SLAVE_ADDRESS, AK8963_CNTL1, (mfs << 4 | mode))
        time.sleep(0.01)

    ## brief Check data ready
    #  @param [in] self The object pointer.
    #  @retval true data is ready
    #  @retval false data is not ready
    def checkDataReady(self):
        drdy = self.bus.read_byte_data(self.address, INT_STATUS)
        if drdy & 0x01:
            return True
        else:
            return False

    ## Read accelerometer
    #  @param [in] self The object pointer.
    #  @retval x : x-axis data
    #  @retval y : y-axis data
    #  @retval z : z-axis data
    def readAccel(self):
        data = self.bus.read_i2c_block_data(self.address, ACCEL_OUT, 6)
        x = self.dataConv(data[1], data[0])
        y = self.dataConv(data[3], data[2])
        z = self.dataConv(data[5], data[4])

        x = round(x * self.ares, 3)
        y = round(y * self.ares, 3)
        z = round(z * self.ares, 3)

        return [x, y, z]

    ## Read gyro
    #  @param [in] self The object pointer.
    #  @retval x : x-gyro data
    #  @retval y : y-gyro data
    #  @retval z : z-gyro data
    def readGyro(self):
        data = self.bus.read_i2c_block_data(self.address, GYRO_OUT, 6)

        x = self.dataConv(data[1], data[0])
        y = self.dataConv(data[3], data[2])
        z = self.dataConv(data[5], data[4])

        x = round(x * self.gres, 3)
        y = round(y * self.gres, 3)
        z = round(z * self.gres, 3)

        return [x, y, z]


    ## Read magneto
    #  @param [in] self The object pointer.
    #  @retval x : X-magneto data
    #  @retval y : y-magneto data
    #  @retval z : Z-magneto data
    def readMagnet(self):
        x = 0
        y = 0
        z = 0

        # check data ready
        drdy = self.bus.read_byte_data(AK8963_SLAVE_ADDRESS, AK8963_ST1)
        if drdy & 0x01:
            data = self.bus.read_i2c_block_data(AK8963_SLAVE_ADDRESS, AK8963_MAGNET_OUT, 7)

            # check overflow
            if (data[6] & 0x08) != 0x08:
                x = self.dataConv(data[0], data[1])
                y = self.dataConv(data[2], data[3])
                z = self.dataConv(data[4], data[5])

                x = round(x * self.mres * self.magXcoef, 3)
                y = round(y * self.mres * self.magYcoef, 3)
                z = round(z * self.mres * self.magZcoef, 3)

        return [x, y, z]

    ## Read temperature
    #  @param [out] temperature temperature(degrees C)
    def readTemperature(self):
        data = self.bus.read_i2c_block_data(self.address, TEMP_OUT, 2)
        temp = self.dataConv(data[1], data[0])

        temp = round((temp / 333.87 + 21.0), 3)
        return temp

    ## Data Convert
    # @param [in] self The object pointer.
    # @param [in] data1 LSB
    # @param [in] data2 MSB
    # @retval Value MSB+LSB(int 16bit)
    def dataConv(self, data1, data2):
        value = data1 | (data2 << 8)
        if (value & (1 << 16 - 1)):
            value -= (1 << 16)
        return value


class IMU(Sensor):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.send = partial(self.send, sensor_type=SensorType.SENSOR_IMU)  # note: all inputs should use keyword args
        self.log = partial(self.log, sensor_type=SensorType.SENSOR_IMU)
        self.__sensor_handles = self.__init_sensors()  # todo
        self.__thread_dict = {}
        self.__active_flag_list = {sensor_name: False for sensor_name in self.__sensor_handles.keys()}

    def __init_sensors(self):
        if "test.mock.mock_sensors.mock_imu" not in SENSOR_LIST:
            self.log(level='info',
                     msg="Please ensure that the SENSOR_LIST variable in your config file has 'test.mock.mock_sensors.mock_imu'")

        if "sensors.imu" not in SENSOR_LIST:
            self.log(level='info',
                     msg="Please ensure that the SENSOR_LIST variable in your config file has 'sensors.imu'")

        sensors = {}
        try:
            sensors["sensors.imu"] = MPU9250()
        except Exception as e:
            self.log(level='warning',
                     msg=f"Unable to init 'sensors.imu': {traceback.format_exc()}")
        else:
            self.log(level='info',
                     msg="init sensor.imu successfully")

        try:
            sensors["test.mock.mock_sensors.mock_imu"] = MOCKIMU()
        except Exception as e:
            self.log(level='warning',
                     msg=f"Unable to init 'test.mock.mock_sensors.mock_imu': {traceback.format_exc()}")
        else:
            self.log(level='info',
                     msg="init test.mock.mock_sensors.mock_imu success")

        return sensors

    def get_sensors_list(self):
        return self.__sensor_handles.keys()

    def activate(self, sensor: str, config: SENSOR_SETTING):
        self.log(level='info', msg=f"activate {sensor}")
        if sensor in self.__sensor_handles and self.__sensor_handles[sensor] is not None:
            sensor_name = sensor
        else:
            self.log(level="warning",
                     msg=f"unable to activate {sensor}")
            return

        if sensor_name not in self.__thread_dict:  # note: need to guarantee all these threads won't crash, because these threads will only start once.
            self.__thread_dict[sensor_name] = Thread(target=self.__read_sensor_data, args=(sensor_name, config))
            self.__thread_dict[sensor_name].start()

        self.__active_flag_list[sensor_name] = True  # note: gurantee that __active_flag is only changed by sensor_manager which is only one thread exist in this process

    def deactivate(self):
        self.__active_flag_list = {sensor_name: False for sensor_name, activate_status in self.__active_flag_list}

    def configure(self, config):
        pass

    def __read_sensor_data(self, sensor_name: str, config: SENSOR_SETTING):
        imu_handle = self.__sensor_handles[sensor_name]
        sleep_time = 0.01 if config is None else config.time_period_sec
        try:
            while True:
                if self.__active_flag_list[sensor_name]:
                    accel = imu_handle.readAccel()
                    gyro = imu_handle.readGyro()
                    mag = imu_handle.readMagnet()
                    self.send(values=accel + gyro + mag)
                time.sleep(sleep_time)
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    # todo: should be able to run here to get quick sense on what data looks like without running the whole system
    try:
        imu_handle = MPU9250()
        while True:
            accel = imu_handle.readAccel()
            gyro = imu_handle.readGyro()
            mag = imu_handle.readMagnet()
            values = accel + gyro + mag
            print(values)
    except KeyboardInterrupt:
        pass

