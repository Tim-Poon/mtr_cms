import sys
import os
full_path = os.path.abspath(__file__)
dir_name = os.path.dirname(full_path)
sys.path = [dir_name] + sys.path
from common.router import Router
from common.component import Component
import config.common as config
import importlib
import atexit

#
# # todo: inherite multiprocessing manager when writing __router?
#
#
# def start_estimator(sensor_data_queue, estimation_result_queue):
#     pass
#
#
# def start_basic_services(sensor_data_queue, estimation_result_queue):
#     from common.router import Router
#     from monitor.system_monitor import SystemMonitor
#     from sensors.sensor_manager import SensorManager
#
#     # todo: where to do the registration? configuration is the default registration set.
#     # todo: sensor_manager in other process? hard to control sensor manager then?
#     sensor_manager = SensorManager()
#
#     router = Router()  # todo: when will the connection to outside world(db, apiserver, multiprocess-queue) break? Should __router recreate it?
#
#     router_thread = Thread(target=router.loop_forever)
#     router_thread.start()
#
#
#     system_monitor_thread = Thread(target=SystemMonitor().watch, args=(router, ))
#     system_monitor_thread.start()
#
#
# def start_sensor_manager(sensor_data_queue):
#     from sensors.sensor_manager import SensorManager
#     sensor_manager = SensorManager()
#
# # todo: multiprocessing manager
#
#
# if __name__ == "__main__":
#     sensor_data_q = Queue()
#
#     estimator_process = Process(target=start_estimator, args=(sensor_data_q, ))
#     basic_services_process = Process(target=start_basic_services, args=(sensor_data_q,))
#
#     try:
#         while 1:
#             if not estimator_process.is_alive():
#                 estimator_process.start()
#             if not basic_services_process.is_alive():
#                 basic_services_process.start()
#             time.sleep(1)
#     except Exception as e:
#         # todo: pay attention to thread error and process error.
#         pass


def on_exit():
    import RPi.GPIO as GPIO
    GPIO.cleanup()
    print('on_exit: exit')


if __name__ == "__main__":
    Router().loop_forever(daemon=True)
    loaded_modules = []
    for m, flag in config.TO_LOAD_MODULES.items():
        if flag:
            loaded_modules.append(importlib.import_module(name=m))

    for m in Component._components:
        m.start()

    atexit.register(on_exit)
