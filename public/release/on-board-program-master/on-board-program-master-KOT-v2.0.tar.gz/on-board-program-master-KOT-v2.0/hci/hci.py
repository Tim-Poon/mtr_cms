import hci.led as led
# import hci.button as button
import hci.conf as conf
import RPi.GPIO as GPIO
# import time
# import asyncio
# import argparse
# from multiprocessing import Process
# from common.component import Component
# from threading import Thread
# from multiprocessing import Process, Lock
# from queue import Queue, Empty
# from common.event import Event
# import time
# import hci.fan as fan
import time
# from typing import List
from common.component import Component
# from threading import Thread
# from multiprocessing import Process, Lock, Queue
# import queue
from common.event import *
from config.common import PI_BLE_MAC_ADDR
import threading
# from hci.led import LED
# from hci.fan import FAN
# import hci.fan as fan_control
import hci.speaker as speaker
from collections import defaultdict


class HCI(Component):
	def __init__(self):
		super().__init__()
		# self.add_event_listener("sensor_data", self.__sensors_visulization_on)
		self.add_event_publisher(HCIStatusEvent._event_type)
		self.add_event_listener(SystemStatusEvent._event_type, self._visualization_on)
		self.gpio_initialization()
		#self.pwm_led_list = [GPIO.PWM(conf.LED_PINS["GREEN_LED"].pin, conf.LED_PARAMS["LED_PWM"]),GPIO.PWM(conf.LED_PINS["RED_LED"].pin, conf.LED_PARAMS["LED_PWM"])]
		#self.pwm_initialization()
		self.add_event_listener(ResultEvent._event_type, self.alarm)
		self.add_event_listener(StepAlarmEvent._event_type, self.alarm)
		self.alarm_status = defaultdict(float)

	def start(self):
		pass

	def gpio_initialization(self):
		GPIO.setmode(GPIO.BOARD)  # setup the board mode
		for led_color, led_info in conf.LED_PINS.items():
			GPIO.setup(led_info.pin, GPIO.OUT)

	# def pwm_initialization(self):
	# 	for pwm in self.pwm_led_list:
	# 		pwm.start(conf.LED_PARAMS["LED_LIGHT_STRENGTH"])

	def alarm(self, event: ResultEvent):
		if isinstance(event, ResultEvent) and event.value.overspeed_alarm > 0:
			speaker.speaker(conf.SPEAKER_PARAMS['SPEAKER_PIN'],
							conf.SPEAKER_PARAMS['SPEAKER_LOOP'],
							conf.SPEAKER_PARAMS['SPEAKER_TIME_INTERVAL'])

	# alarm = 0
		# if isinstance(event, ResultEvent):
		# 	overspeed_alarm = event.value.overspeed_alarm
		# 	alarm |= overspeed_alarm
		# 	if overspeed_alarm:
		# 		self.alarm_status['overspeed_alarm']=event.timestamp
		# elif isinstance(event, StepAlarmEvent):
		# 	step_alarm = event.value
		# 	alarm |= step_alarm
		# 	if step_alarm:
		# 		self.alarm_status['step_alarm'] = event.timestamp
		# else:
		# 	return
		# if (isinstance(event, StepAlarmEvent) and event.step >= 10) or (alarm and abs(self.alarm_status['overspeed_alarm']-self.alarm_status['step_alarm'])<=3):
		# 	speaker.speaker(conf.SPEAKER_PARAMS['SPEAKER_PIN'],
		# 					conf.SPEAKER_PARAMS['SPEAKER_LOOP'],
		# 					conf.SPEAKER_PARAMS['SPEAKER_TIME_INTERVAL'])

	def _visualization_on(self, event: Event):
		led_status_dict = {"ORANGE_LED": False, "WHITE_LED": False, "YELLOW_LED": False, "BLUE_LED": False, "GREEN_LED": False, "RED_LED": False}
		led.led_control(conf.LED_PINS["GREEN_LED"].pin, True)
		led_status_dict['GREEN_LED'] = True
		if event.event_type == SystemStatusEvent._event_type:
			status_dict = event.status_dict
			# print(status_dict)
			pi_voltage_information = status_dict['pi_voltage']
			pi_voltage_processed = str(pi_voltage_information).replace("throttled=", "")
			pi_voltage_final = str(pi_voltage_processed).replace("\n", "")
			if led.under_voltage_detection(list(bin(int(pi_voltage_final, 16)))):
				led_status_dict['RED_LED'] = True
		self.publish(HCIStatusEvent(identifier=PI_BLE_MAC_ADDR, value=led_status_dict))

	# GPIO.PWM(conf.LED_PINS["RED_LED"].pin, conf.LED_PARAMS["LED_PWM"]).stop()
	# CPU_temperature = status_dict['CPU_temperature']
	# CPU_temperature_final = float(CPU_temperature.replace("C", ""))
	# print(f"CPU_temperature {CPU_temperature_final}")
# elif event.event_type == 'sensor_data':
#     if event.sensor_type == SensorType.SENSOR_BLE:


#         #beacon_data = event.values
#         self.count_ble+=1
#         #print(f"beacon_data {self.count_ble}")
#     elif event.sensor_type == SensorType.SENSOR_IMU:
#          self.count_imu += 1
#          #print(f"imu_data {self.count_imu}")
#          #imu_data = event.values
# print(f"all data {self.count_ble, self.count_imu}, average_data per second ({round((self.count_ble/(time.time(
# )-self.start_time)),2)},{round((self.count_imu/(time.time()-self.start_time)),2)})")
# for pin in pin_list:
#     GPIO.setup(pin, GPIO.OUT)
#     pwm_led = GPIO.PWM(pin, 100)
#     pwm_led_list.append(pwm_led)
# led.leds_group(pin_list, pwm_led_list, conf.led_light_strength[1])
# GPIO.setup(conf.fan_pin, GPIO.OUT, initial=GPIO.LOW)
# fan = GPIO.PWM(conf.fan_pin, conf.PWM_freq)
# FAN(2, "fan_on", 2, CPU_temperature_final, conf, fan).start()
# time.sleep(2)
# GPIO.cleanup()

# network_status = status_dict['network_status']
# if network_status == "Connected to Network!":
#     LED(3, "network_light_on", 3, conf.led_pins[4],pwd_led_list[4], flag).start()

# def __control_on(self):


#     temperature = get()
#     Thread(target=fan.fan_control(temperature, conf)).start()
#     Thread(target=button.button_control(conf.button_on_pin, conf.button_off_pin)).start()


if __name__ == '__main__':
	pass
